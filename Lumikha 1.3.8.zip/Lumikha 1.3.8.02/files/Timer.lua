Timer = {
	new = function(tick)
		local t = os.time()
		local isStarted = false
		local tick = tick or 0
		
		local time = function(self)
			if isStarted then 
				return os.time() - t
			else 
				return tick 
			end
		end

		local stop = function(self)
			if isStarted then
				isStarted = false
				tick = os.time() - t
			end
		end

		local start = function(self)
			if not isStarted then
				isStarted = true
				t = os.time() - tick
			end
		end

		local reset = function(self)
			t = os.time()
			isStarted = false
			tick = 0
		end
	
		local isRunning = function(self)
			return isStarted
		end
		
		local setTick = function(self, v)
			v = tonumber(v) or 0
			t = os.time() - v
		end
		
		return{
			time = time,
			stop = stop,
			start = start,
			reset = reset,
			isRunning = isRunning,
			setTick = setTick,
		}
	end
}