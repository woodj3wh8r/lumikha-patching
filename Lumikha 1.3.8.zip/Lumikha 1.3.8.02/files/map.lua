-------------------------------------------------------------------------------
--  Lumikha
--  Copyright (C) 2011 Fantasix
--
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
-------------------------------------------------------------------------------

-- ****************** MAP ****************** --

map = {}

function map.load()
	map.breakTiles = Image.load("images/break.png", VRAM)
	map.breakTimer = Timer.new()
	map.breakCanvas = Canvas.new()
	map.breakCanvObj = Canvas.newImage(0,0, map.breakTiles, 0, 0, 16, 16)
	map.breakTimerLimit = 0
	Canvas.add(map.breakCanvas, map.breakCanvObj)
	map.breakX = 0
	map.breakY = 0
	map.breakState = 0

	map.filePath = "saves/"..worldNumber.."/map.map"
	map.hei = 64
	map.wid = 256
	map.bgc = Color.new(18,19,31)
	
	local file = io.open("saves/"..worldNumber.."/misc.ftsx", "r")
	local tab = {}
	local line = file:read()

	while line do
		if string.byte(string.sub(line, -1,-1)) == 13 or string.byte(string.sub(line, -1,-1)) == 10 then
			line = string.sub(line , 1, -2)
		end
		
		table.insert(tab, line)
		line = file:read()
	end

	io.close() 

	map.scrollX = tonumber(tab[3])
	map.scrollY = tonumber(tab[4])

	map.lightTiles = Image.load("images/lightTiles.png", VRAM)
	
	map.lightMap = ScrollMap.new(map.lightTiles , "saves/"..worldNumber.."/light.map", map.wid, map.hei, 16, 16)
	
	map.scrollMap = ScrollMap.new(data.items , map.filePath, map.wid, map.hei, 16, 16)
end

function map.destroy()
	Image.destroy(map.breakTiles)
	map.breakTiles = nil
	Image.destroy(map.lightTiles)
	map.lightTiles = nil
	Canvas.destroy(map.breakCanvas)
	ScrollMap.destroy(map.scrollMap)
	map.scrollMap = nil
	ScrollMap.destroy(map.lightMap)
	map.lightMap = nil
end

function map.draw()
	--local cY = char.posY+(map.scrollY/16)
	
	-- Exterieur
	if map.scrollY <= 384 then
		if map.scrollY > 192 then
			screen.drawFillRect(SCREEN_DOWN, 0, 0, 256, 192-(map.scrollY-192), map.bgc)
		else
			screen.drawFillRect(SCREEN_DOWN, 0, 0, 256, 192, map.bgc)
		end
	end
	
	-- Intersection Exterieur / Mine
	if map.scrollY >= 208 and map.scrollY <= 432 then
		screen.drawGradientRect(SCREEN_DOWN, 0, 192-(map.scrollY-192), 256, 224-(map.scrollY-224), map.bgc, map.bgc, Color.new(5,5,5), Color.new(5,5,5))
	end
	
	-- Mine
	if map.scrollY >= 272 then
		if map.scrollY < 448 then
			screen.drawFillRect(SCREEN_DOWN, 0, 192, 256, 192-(map.scrollY-256), Color.new(5,5,5))
		else
			screen.drawFillRect(SCREEN_DOWN, 0, 0, 256, 192, Color.new(5,5,5))
		end
	end
	
	timeCycle.draw()
	
	ScrollMap.scroll(map.scrollMap, map.scrollX, map.scrollY)
	
	ScrollMap.draw(SCREEN_DOWN, map.scrollMap)
end

function map.lightMapDraw()
	ScrollMap.scroll(map.lightMap, map.scrollX, map.scrollY)
	
	ScrollMap.draw(SCREEN_DOWN, map.lightMap)
end

function map.resetBreaker()
	if map.breakState > 0 or map.breakTimer:time() > 0 then
		map.breakState = 0
		map.breakX = 0
		map.breakY = 0
		Canvas.setAttr(map.breakCanvObj, ATTR_X2, 0)
		map.breakTimer:reset()
		char.isBreaking = false
	end
end

function map.lightActualize(xL, yL, r)
	for y = -r, r do
		for x = -r, r do
			local dist = math.abs(math.abs(y+yL)-yL) + math.abs(math.abs(x+xL)-xL)
			if dist <= r and xL+x >= 0 and xL+x < map.wid and yL+y >= 0 and yL+y < 64 then
				local t = (2-(r-dist))
				if t < 0 or t > 2 then
					t = 0
				end
				if ScrollMap.getTile(map.lightMap, xL+x, yL+y) > t then
					ScrollMap.setTile(map.lightMap, xL+x, yL+y, t)
				end
			end
		end
	end
end

function map.blocChecker(bX,bY)
	for y = -1, 1, 2 do
		if bY + y >= 0 and bY + y <= map.hei then
			local id = ScrollMap.getTile(map.scrollMap, bX, bY + y)
			-- Sapling
			if id == 97 then
				if not data.tab[97].setCondition(bX, bY + y) then
					ScrollMap.setTile(map.scrollMap, bX, bY + y, 0)
					inventory.addItem(97)
					sapling.remove(bX, bY + y)
				end
			end	
			-- Dead Sapling
			if id == 101 then
				if not data.tab[101].setCondition(bX, bY + y) then
					ScrollMap.setTile(map.scrollMap, bX, bY + y, 0)
				end
			end	
		end
	end
	for x = -1, 1, 2 do
		if bX + x >= 0 and bX + x <= map.wid then
			local id = ScrollMap.getTile(map.scrollMap, bX + x, bY)

		end
	end
end