-------------------------------------------------------------------------------
--  Lumikha
--  Copyright (C) 2011 Fantasix
--
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
-------------------------------------------------------------------------------
-- ****************** CHARACTER ****************** --

char = {}

function char.load()
	char.sprite = Sprite.new("images/mc_sprites3.png", 16, 32, VRAM)

	char.sprite:addAnimation({0,1}, 200)
	char.sprite:addAnimation({2,3}, 200)
	char.sprite:addAnimation({4,5}, 200)

	local file = io.open("saves/"..worldNumber.."/misc.ftsx", "r")
	local tab = {}
	local line = file:read()

	while line do
		if string.byte(string.sub(line, -1,-1)) == 13 or string.byte(string.sub(line, -1,-1)) == 10 then
			line = string.sub(line , 1, -2)
		end
		
		table.insert(tab, line)
		line = file:read()
	end

	io.close() 

	char.posX = tonumber(tab[1])
	char.posY = tonumber(tab[2])

	file = nil
	tab = nil
	line = nil

	char.dir = 0
	char.movement = false
	char.isBreaking = false

	char.afterSetTimer = Timer.new()
	char.afterSetTimer:start()

	char.moveTimer = Timer.new()
	char.moveTimer:start()
	char.gravityTimer = Timer.new()
	char.gravityTimer:start()
end

function char.destroy()
	char.sprite:destroy()
	char.sprite = nil
end

function char.move()
	local cY =  math.ceil((char.posY+16+1)/16) -- Couche Y du perso
	local pY = char.posY + map.scrollY / 16
	local pX = char.posX + map.scrollX / 16
	
	if char.gravityTimer:time() > 150 then
		char.gravityTimer:stop()
		
		if not char.climbing and pY < map.hei - 1 and data.tab[ScrollMap.getTile(map.scrollMap, pX, pY + 1)].passable and not data.tab[ScrollMap.getTile(map.scrollMap, pX, pY)].standOn then
			
			char.gravityTimer:reset()
			char.gravityTimer:start()
			if char.posY + 1 > 6 and map.scrollY + char.posY*16 + 96 < map.hei * 16 then
				map.scrollY = map.scrollY + 16
			else
				char.posY = char.posY + 1
			end
		end
	end
	
	if Ambi.held.Right() then
		char.dir = 0	
	elseif Ambi.held.Left() then
		char.dir = 1
	end
	
	if char.isBreaking then
		char.movement = false
	end
	
	if char.moveTimer:time() > 150 and not char.isBreaking then
		char.moveTimer:stop()
		
		if pX < map.wid - 1 and pY - 1 > 0 and Ambi.held.Right() and not Ambi.held.Left() and Ambi.held.Up() and not data.tab[ScrollMap.getTile(map.scrollMap, pX + 1, pY)].passable and not data.tab[ScrollMap.getTile(map.scrollMap, pX, pY + 1)].passable and data.tab[ScrollMap.getTile(map.scrollMap, pX + 1, pY - 1)].passable and data.tab[ScrollMap.getTile(map.scrollMap, pX + 1, pY - 2)].passable and data.tab[ScrollMap.getTile(map.scrollMap, pX, pY - 2)].passable then -- Jump Right
			if char.posX + 1 > 8 and map.scrollX + char.posX*16 + 128 < map.wid*16 then
				map.scrollX = map.scrollX + 16
			else
				char.posX = char.posX + 1
			end
			if char.posY - 1 < 6 and map.scrollY > 0 then
				map.scrollY = map.scrollY - 16
			else
				char.posY = char.posY - 1
			end
			char.movement = true
			char.moveTimer:reset()
			char.moveTimer:start()
		elseif pX > 0 and pY - 1 > 0 and Ambi.held.Left() and not Ambi.held.Right() and Ambi.held.Up() and not data.tab[ScrollMap.getTile(map.scrollMap, pX - 1, pY)].passable and not data.tab[ScrollMap.getTile(map.scrollMap, pX, pY + 1)].passable and data.tab[ScrollMap.getTile(map.scrollMap, pX - 1, pY - 1)].passable and data.tab[ScrollMap.getTile(map.scrollMap, pX - 1, pY - 2)].passable and data.tab[ScrollMap.getTile(map.scrollMap, pX, pY - 2)].passable then -- Jump Left
			if char.posX - 1 < 8 and map.scrollX > 0 then
				map.scrollX = map.scrollX - 16
			else
				char.posX = char.posX - 1
			end
			if char.posY - 1 < 6 and map.scrollY > 0 then
				map.scrollY = map.scrollY - 16
			else
				char.posY = char.posY - 1
			end
			char.movement = true
			char.moveTimer:reset()
			char.moveTimer:start()
		elseif pX < map.wid - 1 and Ambi.held.Right() and not Ambi.held.Left() and data.tab[ScrollMap.getTile(map.scrollMap, pX + 1, pY)].passable and data.tab[ScrollMap.getTile(map.scrollMap, pX + 1, pY - 1)].passable then -- Go Right
			if char.posX + 1 > 8 and map.scrollX + char.posX*16 + 128 < map.wid*16 then
				map.scrollX = map.scrollX + 16
			else
				char.posX = char.posX + 1
			end
			char.movement = true
			char.moveTimer:reset()
			char.moveTimer:start()
		elseif pX > 0 and Ambi.held.Left() and not Ambi.held.Right() and data.tab[ScrollMap.getTile(map.scrollMap, pX - 1, pY)].passable and data.tab[ScrollMap.getTile(map.scrollMap, pX - 1, pY - 1)].passable then -- Go Left
			if char.posX - 1 < 8 and map.scrollX > 0 then
				map.scrollX = map.scrollX - 16
			else
				char.posX = char.posX - 1
			end
			char.movement = true
			char.moveTimer:reset()
			char.moveTimer:start()
		else
			char.movement = false
		end
	end
end

function char.draw()
	if char.movement then
		char.sprite:playAnimation(SCREEN_DOWN, char.posX*16, char.posY*16-16, 1+char.dir) 
	elseif char.climbing then
		char.sprite:playAnimation(SCREEN_DOWN, char.posX*16, char.posY*16-16, 3) 
	elseif char.isBreaking and not char.climbing then
		char.sprite:drawFrame(SCREEN_DOWN, char.posX*16, char.posY*16-16, 1+char.dir*2)
	else
		char.sprite:drawFrame(SCREEN_DOWN, char.posX*16, char.posY*16-16, 0+char.dir*2)
	end
end

function char.isAtProximity(x, y)
	if math.abs(x-char.posX) <= 1 and (math.abs(y-char.posY) <= 1 or math.abs(y-(char.posY-1)) <= 1) then
		return true
	end
	return false
end

function char.dig()
	if Stylus.held and (not Ambi.held.Up() or char.climbing) and char.afterSetTimer:time() > 500 then
		local sX = math.floor(Stylus.X/16)
		local sY = math.floor(Stylus.Y/16)
		local cX = char.posX*16 + 8
		local cY = char.posY*16
		local x = sX + map.scrollX / 16
		local y = sY + map.scrollY / 16
		local blockID = ScrollMap.getTile(map.scrollMap, x, y)
		
		if char.isAtProximity(sX, sY) and blockID > 0 then
			if sX > char.posX then 
				char.dir = 0
			elseif sX < char.posX then 
				char.dir = 1
			end
			if map.breakTimer:time() == 0 then
				map.breakTimer:start()
				map.breakX = x
				map.breakY = y
				char.isBreaking = true
				
				local tool
				local actualType
				local timeToBreak = data.tab[blockID].timeToBreak
				
				if inventory.tab[inventory.selectedIndex][1] then
					tool = data.tab[blockID].toolToDestroy
					actualType = data.tab[inventory.tab[inventory.selectedIndex][1]].type
					toolBreak = data.tab[blockID].toolBreak
				end
				
				if not timeToBreak then
					timeToBreak = 2000
				end
				
				if tool and actualType and tool == actualType then
					if toolBreak then
						timeToBreak = toolBreak
					end
					map.breakTimerLimit = timeToBreak - (data.tab[inventory.tab[inventory.selectedIndex][1]].level) * math.ceil(timeToBreak/8)
				else
					map.breakTimerLimit = timeToBreak
				end
				
				if timeToBreak == -1 then
					map.breakTimer:reset()
					char.isBreaking = false
				end
				
			elseif map.breakTimer:time() > map.breakTimerLimit and map.breakX == x and map.breakY == y then -- Break r�ussi
				local dropID = blockID
				
				if data.tab[blockID].dropedBlock then
					if type(data.tab[blockID].dropedBlock) == "number" then
						dropID = data.tab[blockID].dropedBlock
					else
						dropID = 0
						for k, v in pairs(data.tab[blockID].dropedBlock) do
							if math.random(1,100) <= v[2] then
								dropID = v[1]
								break
							end
						end
					end
				end
				if dropID > 0 then
					if data.tab[blockID].dropConditions then
						if inventory.tab[inventory.selectedIndex][1] and data.tab[inventory.tab[inventory.selectedIndex][1]].type == data.tab[blockID].dropConditions[1] and data.tab[inventory.tab[inventory.selectedIndex][1]].level >= data.tab[blockID].dropConditions[2] then
							inventory.addItem(dropID)
						end
					else
						inventory.addItem(dropID)
					end
				end	
				
				map.resetBreaker()
								
				ScrollMap.setTile(map.scrollMap, x, y, 0)
								
				if data.tab[blockID].onDestroy then
					data.tab[blockID].onDestroy(x, y)
				end
				
				map.blocChecker(x,y)
				
				map.lightActualize(x, y, 3)
			elseif map.breakX ~= x or map.breakY ~= y then
				map.resetBreaker()
			else
				if map.breakState ~= math.floor(map.breakTimer:time()/(map.breakTimerLimit/10)) then
					map.breakState = math.floor(map.breakTimer:time()/(map.breakTimerLimit/10))
					Canvas.setAttr(map.breakCanvObj, ATTR_X2, map.breakState*16)
				end
				char.isBreaking = true
				Canvas.draw(SCREEN_DOWN, map.breakCanvas, sX*16, sY*16)
			end
		else
			map.resetBreaker()
		end
	else
		map.resetBreaker()
	end
end

function char.setBlock()
	if char.afterSetTimer:time() > 500 then
		char.afterSetTimer:stop()
	end
	if Stylus.newPress then
		local sX = math.floor(Stylus.X/16)
		local sY = math.floor(Stylus.Y/16)
		local x = sX + map.scrollX / 16
		local y = sY + map.scrollY / 16
		local blockData = data.tab[inventory.tab[inventory.selectedIndex][1]]
		
		if inventory.tab[inventory.selectedIndex][1] and blockData.type == "block" and char.isAtProximity(sX, sY) and (((sX ~= char.posX or sY ~= char.posY) or blockData.passable) and ((sX ~= char.posX or sY ~= char.posY-1) or blockData.passable)) and ScrollMap.getTile(map.scrollMap, x, y) == 0 then
			if not blockData.setCondition or blockData.setCondition(x, y) then
				ScrollMap.setTile(map.scrollMap, x, y, inventory.tab[inventory.selectedIndex][1])
				
				if blockData.onSet then
					blockData.onSet(x, y)
				end
				
				inventory.removeItem(inventory.selectedIndex)
				char.afterSetTimer:reset()
				char.afterSetTimer:start()
			end
		end
	end
end
function char.act()
	local x = char.posX + map.scrollX / 16
	local y = char.posY + map.scrollY / 16
	local limitY = map.scrollY + char.posY*16 + 96
	
	-- Actions de l'echelle
	if ScrollMap.getTile(map.scrollMap, x, y ) == 81 and y < map.hei * 16 and data.tab[ScrollMap.getTile(map.scrollMap, x, y + 1)].passable then
		char.climbing = true
	else
		char.climbing = false
	end
	if Ambi.held.Up() and y - 1 > 0 and ScrollMap.getTile(map.scrollMap, x, y ) == 81 and ScrollMap.getTile(map.scrollMap, x, y - 1) == 81 then
		if char.moveTimer:time() > 150 then
			char.moveTimer:stop()
			if data.tab[ScrollMap.getTile(map.scrollMap, x, y - 2)].passable then
				if char.posY - 1 < 6 and map.scrollY > 0 then
					map.scrollY = map.scrollY - 16
				else
					char.posY = char.posY - 1
				end
				char.moveTimer:reset()
				char.moveTimer:start()
			end
		end
	end
	if char.climbing and Ambi.held.Down() then
		if char.moveTimer:time() > 150 then
			char.moveTimer:stop()
			if data.tab[ScrollMap.getTile(map.scrollMap, x, y + 1)].passable then
				if char.posY + 1 > 6 and map.scrollY + char.posY*16 + 96 < map.hei * 16 then
					map.scrollY = map.scrollY + 16
				else
					char.posY = char.posY + 1
				end
				char.moveTimer:reset()
				char.moveTimer:start()
			end
		end
	end

	if (Ambi.held.Up() and Stylus.newPress) or Stylus.doubleClick then
		local sX = math.floor(Stylus.X/16)
		local sY = math.floor(Stylus.Y/16)
		local x = sX + map.scrollX / 16
		local y = sY + map.scrollY / 16
		
		if char.isAtProximity(sX, sY) then
			local blockID = ScrollMap.getTile(map.scrollMap, x, y)
			if data.tab[blockID].onClick then
				data.tab[blockID].onClick(x, y)
			end			
		end
	end
end