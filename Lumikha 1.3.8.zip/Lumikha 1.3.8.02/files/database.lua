-------------------------------------------------------------------------------
--  Lumikha
--  Copyright (C) 2011 Fantasix
--
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
-------------------------------------------------------------------------------
data = {}

function data.load()
	data.items = Image.load("images/items_spr_sheet.png", VRAM)
end
function data.destroy()
	Image.destroy(data.items)
	data.items = nil
end

data.tab = {}

-- ****************** BLOCKS ****************** --
-- Air
data.tab[0] = {
	type = "block", 
	name = "",
	coord = {0,0},
	passable = true,
}
-- Wood
data.tab[1] = {
	type = "block", 
	name = "Wood",
	coord = {16,0},
	passable = false,
	stack = 64,
	toolToDestroy = "axe",
	onDestroy = function(bX, bY)
		for y = -1, 1, 2 do
			if bY + y >= 0 and bY + y <= map.hei and ScrollMap.getTile(map.scrollMap, bX, bY + y) == 98 then
				ScrollMap.setTile(map.scrollMap, bX, bY + y, 0)
				if math.random(1,100) <= 20 then -- Sapling
					inventory.addItem(97)
				end
			end
		end
		for x = -1, 1, 2 do
			if bX + x >= 0 and bX + x <= map.wid and ScrollMap.getTile(map.scrollMap, bX + x, bY) == 98 then
				ScrollMap.setTile(map.scrollMap, bX + x, bY, 0)
				if math.random(1,100) <= 20 then -- Sapling
					inventory.addItem(97)
				end
			end
		end
	end,
}
-- Stone
data.tab[2] = {
	type = "block", 
	name = "Stone",
	coord = {32,0},
	passable = false,
	stack = 64,
	toolToDestroy = "pickaxe",
	dropedBlock = 8,
	timeToBreak = 5000,	
	toolBreak = 1000,
	dropConditions = {"pickaxe", 1},
}
-- Dirt
data.tab[3] = {
	type = "block", 
	name = "Dirt",
	coord = {48,0},
	passable = false,
	stack = 64,
	toolToDestroy = "shovel",
	timeToBreak = 1000,
}
-- Grass
data.tab[4] = {
	type = "block", 
	name = "Grass",
	coord = {64,0},
	passable = false,
	stack = 64,
	toolToDestroy = "shovel",
	dropedBlock = 3,
	timeToBreak = 1000,
}
-- Gravel
data.tab[5] = {
	type = "block", 
	name = "Gravel",
	coord = {80,0},
	passable = false,
	stack = 64,
	toolToDestroy = "shovel",
	timeToBreak = 1000,
}
-- Sand
data.tab[6] = {
	type = "block", 
	name = "Sand",
	coord = {96,0},
	passable = false,
	stack = 64,
	toolToDestroy = "shovel",
	timeToBreak = 1000,
	smelted = 13,
}
-- Sandstone
data.tab[7] = {
	type = "block", 
	name = "Sandstone",
	coord = {112,0},
	passable = false,
	stack = 64,
	toolToDestroy = "pickaxe",
	timeToBreak = 5000,	
	toolBreak = 1000,
	pattern = "6|6-6|6",
	givenAmount = 1,
	dropConditions = {"pickaxe", 1},
}
-- Cobblestone
data.tab[8] = {
	type = "block", 
	name = "Cobblestone",
	coord = {128,0},
	passable = false,
	stack = 64,
	toolToDestroy = "pickaxe",
	timeToBreak = 5000,	
	toolBreak = 1000,
	dropConditions = {"pickaxe", 1},
	smelted = 2,
}
-- Moss stone
-- data.tab[9] = {
	-- type = "block", 
	-- name = "Moss stone",
	-- canvObj = Canvas.newImage(0, 0, data.items, 144, 0, 16, 16),
	-- canvas = Canvas.new(),
	-- passable = false,
	-- stack = 64,
	-- toolToDestroy = "pickaxe",
-- }
-- Bedrock
data.tab[10] = {
	type = "block", 
	name = "Bedrock",
	coord = {160,0},
	passable = false,
	stack = 64,
	timeToBreak = -1,
}
-- Wooden Plank
data.tab[11] = {
	type = "block", 
	name = "Wooden Plank",
	coord = {176,0},
	passable = false,
	pattern = "1",
	givenAmount = 4,
	stack = 64,
	toolToDestroy = "axe",
}
-- Brick
-- data.tab[12] = {
	-- type = "block", 
	-- name = "Brick",
	-- canvObj = Canvas.newImage(0, 0, data.items, 192, 0, 16, 16),
	-- canvas = Canvas.new(),
	-- passable = false,
	-- stack = 64,
	-- toolToDestroy = "pickaxe",
-- }
-- Glass
data.tab[13] = {
	type = "block", 
	name = "Glass",
	coord = {208,0},
	passable = false,
	stack = 64,
	dropedBlock = 0,
	timeToBreak = 500,
}
-- Coal Ore
data.tab[16] = {
	type = "block", 
	name = "Coal Ore",
	coord = {0,16},
	passable = false,
	toolToDestroy = "pickaxe",
	dropedBlock = 275,
	stack = 64,
	timeToBreak = 5000,	
	toolBreak = 1200,
	dropConditions = {"pickaxe", 1},
}
-- Iron Ore
data.tab[17] = {
	type = "block", 
	name = "Iron Ore",
	coord = {16,16},
	passable = false,
	toolToDestroy = "pickaxe",
	stack = 64,
	timeToBreak = 5000,	
	toolBreak = 1200,
	dropConditions = {"pickaxe", 2},
	smelted = 273,
}
-- Gold Ore
data.tab[18] = {
	type = "block", 
	name = "Gold Ore",
	coord = {32,16},
	passable = false,
	toolToDestroy = "pickaxe",
	stack = 64,
	timeToBreak = 5000,	
	toolBreak = 1200,
	dropConditions = {"pickaxe", 3},
	smelted = 276,
}
-- Diamond Ore
data.tab[19] = {
	type = "block", 
	name = "Diamond Ore",
	coord = {48,16},
	passable = false,
	toolToDestroy = "pickaxe",
	dropedBlock = 274,
	stack = 64,
	timeToBreak = 5000,	
	toolBreak = 1200,
	dropConditions = {"pickaxe", 3},
}
-- Iron Block
data.tab[33] = {
	type = "block", 
	name = "Iron Block",
	coord = {16,32},
	passable = false,
	toolToDestroy = "pickaxe",
	stack = 64,
	timeToBreak = 5000,	
	toolBreak = 1200,
	pattern = "273|273|273-273|273|273-273|273|273",
	givenAmount = 1,
}
-- Gold Block
data.tab[34] = {
	type = "block", 
	name = "Gold Block",
	coord = {32,32},
	passable = false,
	toolToDestroy = "pickaxe",
	stack = 64,
	timeToBreak = 5000,	
	toolBreak = 1200,
	pattern = "276|276|276-276|276|276-276|276|276",
	givenAmount = 1,
}
-- Diamond Block
data.tab[35] = {
	type = "block", 
	name = "Diamond Block",
	coord = {48,16},
	passable = false,
	toolToDestroy = "pickaxe",
	stack = 64,
	timeToBreak = 5000,	
	toolBreak = 1200,
	pattern = "274|274|274-274|274|274-274|274|274",
	givenAmount = 1,
}

-- Crafting Table
data.tab[64] = {
	type = "block", 
	name = "Crafting Table",
	coord = {0,64},
	passable = false,
	stack = 64,
	pattern = "11|11-11|11",
	givenAmount = 1,
	toolToDestroy = "axe",
	onClick = function() 
		craftingTableAct()
	end,
}
-- Chest
data.tab[65] = {
	type = "block", 
	name = "Chest",
	coord = {16,64},
	passable = false,
	stack = 64,
	pattern = "11|11|11-11|0|11-11|11|11",
	givenAmount = 1,
	toolToDestroy = "axe",
	timeToBreak = 5000,	
	toolBreak = 1000,
	onClick = function(x, y) 
		chest.show(chest.getID(x, y))
	end,
	onSet = function(x, y)
		chest.newC(x, y)
	end,
	onDestroy = function(x, y)
		chest.removeC(x, y)
	end,
}
-- Furnace
data.tab[66] = {
	type = "block", 
	name = "Furnace",
	coord = {32,64},
	passable = false,
	stack = 64,
	pattern = "8|8|8-8|0|8-8|8|8",
	givenAmount = 1,
	toolToDestroy = "pickaxe",
	timeToBreak = 5000,	
	toolBreak = 1000,
	onClick = function(x, y) 
		furnace.show(furnace.getID(x, y))
	end,
	onSet = function(x, y)
		furnace.newF(x, y)
	end,
	onDestroy = function(x, y)
		furnace.removeF(x, y)
	end,
}
-- Burning Furnace
data.tab[67] = {
	type = "block", 
	name = "Burning Furnace",
	dropedBlock = 66,
	coord = {48,64},
	passable = false,
	stack = 64,
	toolToDestroy = "pickaxe",
	timeToBreak = 5000,	
	toolBreak = 1000,
	onClick = function(x, y) 
		furnace.show(furnace.getID(x, y))
	end,
	onSet = function(x, y)
		furnace.newF(x, y)
	end,
	onDestroy = function(x, y)
		furnace.removeF(x, y)
	end,
}
-- Ladder
data.tab[81] = {
	type = "block", 
	name = "Ladder",
	coord = {16,80},
	passable = true,
	stack = 64,
	pattern = "272|0|272-272|272|272-272|0|272",
	givenAmount = 8,
	toolToDestroy = "axe",	
	standOn = true,
	timeToBreak = 1300,
}
-- Portes 
-- 	Door
data.tab[82] = {
	type = "block", 
	name = "Door",
	coord = {32,80},
	passable = false,
	stack = 64,
	pattern = "11|11-11|11-11|11",
	givenAmount = 1,
	toolToDestroy = "axe",
	timeToBreak = 2000,
	setCondition = function(x, y)
		if ScrollMap.getTile(map.scrollMap, x, y + 1) > 0 and ScrollMap.getTile(map.scrollMap, x, y - 1 ) == 0 then
			return true
		end
		return false
	end,
	onSet = function(x, y)
		ScrollMap.setTile(map.scrollMap, x, y, 83)
		ScrollMap.setTile(map.scrollMap, x, y - 1, 84)
	end,
}
--  Open Door Down
data.tab[83] = {
	type = "block", 
	name = "Open Door Down",
	dropedBlock = 82,
	coord = {48,80},
	passable = true,
	stack = 64,
	toolToDestroy = "axe",
	timeToBreak = 2000,
	setCondition = function(x, y)
		if ScrollMap.getTile(map.scrollMap, x, y + 1) > 0 then
			return true
		end
		return false
	end,
	onClick = function(x, y)
		if char.posX+(map.scrollX/16) ~= x then
			ScrollMap.setTile(map.scrollMap, x, y, 85)
			ScrollMap.setTile(map.scrollMap, x, y - 1, 86)
		end
	end,
	onDestroy = function(x, y)
		ScrollMap.setTile(map.scrollMap, x, y - 1, 0)
	end,
}
--  Open Door Up
data.tab[84] = {
	type = "block", 
	name = "Open Door Up",
	dropedBlock = 82,
	coord = {64,80},
	passable = true,
	stack = 64,
	toolToDestroy = "axe",
	timeToBreak = 2000,
	setCondition = function(x, y)
		if ScrollMap.getTile(map.scrollMap, x, y + 2) > 0 then
			return true
		end
		return false
	end,
	onClick = function(x, y)
		if char.posX+(map.scrollX/16) ~= x then
			ScrollMap.setTile(map.scrollMap, x, y, 86)
			ScrollMap.setTile(map.scrollMap, x, y + 1, 85)
		end
	end,
	onDestroy = function(x, y)
		ScrollMap.setTile(map.scrollMap, x, y + 1, 0)
	end,
}
--  Closed Door Down
data.tab[85] = {
	type = "block", 
	name = "Closed Door Down",
	dropedBlock = 82,
	coord = {80,80},
	passable = false,
	stack = 64,
	toolToDestroy = "axe",
	timeToBreak = 2000,
	setCondition = function(x, y)
		if ScrollMap.getTile(map.scrollMap, x, y + 1) > 0 then
			return true
		end
		return false
	end,
	onClick = function(x, y)
		ScrollMap.setTile(map.scrollMap, x, y, 83)
		ScrollMap.setTile(map.scrollMap, x, y - 1, 84)
	end,
	onDestroy = function(x, y)
		ScrollMap.setTile(map.scrollMap, x, y - 1, 0)
	end,
}
--  Closed Door Up
data.tab[86] = {
	type = "block", 
	name = "Closed Door Up",
	dropedBlock = 82,
	coord = {96,80},
	passable = false,
	stack = 64,
	toolToDestroy = "axe",
	timeToBreak = 2000,
	setCondition = function(x, y)
		if ScrollMap.getTile(map.scrollMap, x, y + 2) > 0 then
			return true
		end
		return false
	end,
	onClick = function(x, y)
		ScrollMap.setTile(map.scrollMap, x, y, 84)
		ScrollMap.setTile(map.scrollMap, x, y + 1, 83)
	end,
	onDestroy = function(x, y)
		ScrollMap.setTile(map.scrollMap, x, y + 1, 0)
	end,
}
-- Sapling
data.tab[97] = {
	type = "block", 
	name = "Sapling",
	coord = {16,96},
	passable = true,
	stack = 64,
	timeToBreak = 500,
	setCondition = function(x, y)
		local t = ScrollMap.getTile(map.scrollMap, x, y + 1)
		if t == 3 or t == 4 then
			return true
		end
		return false
	end,
	onSet = function(x, y)
		sapling.new(x, y)
	end,
	onDestroy = function(x, y)
		sapling.remove(x, y)
	end,
}
-- Leaves
data.tab[98] = {
	type = "block", 
	name = "Leaves",
	coord = {32,96},
	passable = false,
	toolToDestroy = "axe",
	dropedBlock = {{97, 30}},
	stack = 64,
	timeToBreak = 500,
}
-- Dead Sapling
data.tab[101] = {
	type = "block", 
	name = "Dead Sapling",
	coord = {80,96},
	passable = true,
	stack = 64,
	dropedBlock = 0,
	timeToBreak = 500,
	setCondition = function(x, y)
		local t = ScrollMap.getTile(map.scrollMap, x, y + 1)
		if t == 3 or t == 4 then
			return true
		end
		return false
	end,
}
-- ****************** ITEMS ****************** --




-- Wooden sword
data.tab[256] = {
	type = "sword", 
	name = "Wooden sword",
	coord = {192,16},
	level = 1, 
	pattern = "11-11-272"
}
-- Stone sword
data.tab[257] = {
	type = "sword", 
	name = "Stone sword",
	coord = {208,16},
	level = 2, 
	pattern = "8-8-272"
}
-- Iron sword
data.tab[258] = {
	type = "sword", 
	name = "Iron sword",
	coord = {224,16},
	level = 3, 
	pattern = "273-273-272"
}
-- Diamond sword
data.tab[259] = {
	type = "sword", 
	name = "Diamond sword",
	coord = {240,16},
	level = 5, 
	pattern = "274-274-272"
}
-- Wooden shovel
data.tab[260] = {
	type = "shovel", 
	name = "Wooden shovel",
	coord = {192,32},
	level = 1, 
	pattern = "11-272-272"
}
-- Stone shovel
data.tab[261] = {
	type = "shovel", 
	name = "Stone shovel",
	coord = {208,32},
	level = 2, 
	pattern = "8-272-272"
}
-- Iron shovel
data.tab[262] = {
	type = "shovel", 
	name = "Iron shovel",
	coord = {224,32},
	level = 3, 
	pattern = "273-272-272"
}
-- Diamond shovel
data.tab[263] = {
	type = "shovel", 
	name = "Diamond shovel",
	coord = {240,32},
	level = 5, 
	pattern = "0|274|0-0|272|0-0|272|0"
}
-- Wooden pickaxe
data.tab[264] = {
	type = "pickaxe", 
	name = "Wooden pickaxe",
	coord = {192,48},
	level = 1, 
	pattern = "11|11|11-0|272|0-0|272|0"
}
-- Stone pickaxe
data.tab[265] = {
	type = "pickaxe", 
	name = "Stone pickaxe",
	coord = {208,48},
	level = 2, 
	pattern = "8|8|8-0|272|0-0|272|0"
}
-- Iron pickaxe
data.tab[266] = {
	type = "pickaxe", 
	name = "Iron pickaxe",
	coord = {224,48},
	level = 3, 
	pattern = "273|273|273-0|272|0-0|272|0"
}
-- Diamond pickaxe
data.tab[267] = {
	type = "pickaxe", 
	name = "Diamond pickaxe",
	coord = {240,48},
	level = 5, 
	pattern = "274|274|274-0|272|0-0|272|0"
}
-- Wooden axe
data.tab[268] = {
	type = "axe", 
	name = "Wooden axe",
	coord = {192,64},
	level = 1, 
	pattern = "11|11-11|272-0|272"
}
-- Stone axe
data.tab[269] = {
	type = "axe", 
	name = "Stone axe",
	coord = {208,64},
	level = 2, 
	pattern = "8|8-8|272-0|272"
}
-- Iron axe
data.tab[270] = {
	type = "axe", 
	name = "Iron axe",
	coord = {224,64},
	level = 3, 
	pattern = "273|273-273|272-0|272"
}
-- Diamond axe
data.tab[271] = {
	type = "axe", 
	name = "Diamond axe",
	coord = {240,64},
	level = 5, 
	pattern = "274|274-274|272-0|272"
}
-- Stick
data.tab[272] = {
	type = "item", 
	name = "Stick",
	coord = {192,96},
	pattern = "11-11",
	givenAmount = 4,
	stack = 64,
}
-- Iron lingot
data.tab[273] = {
	type = "item", 
	name = "Iron lingot",
	coord = {208,96},
	stack = 64,
	pattern = "33",
	givenAmount = 9,
}
-- Diamond gem
data.tab[274] = {
	type = "item", 
	name = "Diamond gem",
	coord = {224,96},
	stack = 64,
	pattern = "35",
	givenAmount = 9,
}
-- Coal
data.tab[275] = {
	type = "item", 
	name = "Coal",
	coord = {240,96},
	stack = 64,
	fuelTime = 80000
}
-- Gold lingot
data.tab[276] = {
	type = "item", 
	name = "Gold lingot",
	coord = {208,80},
	stack = 64,
	pattern = "34",
	givenAmount = 9,
}