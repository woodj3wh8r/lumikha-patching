-------------------------------------------------------------------------------
--  Lumikha
--  Copyright (C) 2011 Fantasix
--
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
-------------------------------------------------------------------------------

timeCycle = {}

function timeCycle.load()
	timeCycle.img = Image.load("images/sun_moon.png", VRAM)
	
	local file = io.open("saves/"..worldNumber.."/misc.ftsx", "r")
	local tab = {}
	local line = file:read()

	while line do
		if string.byte(string.sub(line, -1,-1)) == 13 or string.byte(string.sub(line, -1,-1)) == 10 then
			line = string.sub(line , 1, -2)
		end
		
		table.insert(tab, line)
		line = file:read()
	end

	io.close() 
	file = nil
	line = nil
	
	timeCycle.timer = Timer.new(tonumber(tab[5]))
	tab = nil
	
	timeCycle.timer:start()
end

function timeCycle.destroy()
	Image.destroy(timeCycle.img)
	timeCycle.img = nil
	timeCycle.timer = nil
end

function timeCycle.act()
	if timeCycle.timer:time() > 512000 then
		timeCycle.timer:reset()
		timeCycle.timer:start()
	end
	
	local t = math.floor(timeCycle.timer:time() / 1000 )
	if map.scrollY <= 288 then
		if t >= 8 and t <= 248 then -- Daytime
			map.bgc = Color.new(18,24,31)
		elseif t >= 264 and t <= 504 then -- NightTime
			map.bgc = Color.new(2,8,15)
		elseif t >= 248 and t <= 264 then -- Sun Dawn
			local d = (t-248)
			map.bgc = Color.new(18-d, 24-d, 31-d)
		elseif t >= 504 or t <= 8 then -- Sun Set
			if t >= 504 then
				local d = (t-504)
				map.bgc = Color.new(2+d,8+d,15+d)
			else
				local d = 8+t
				map.bgc = Color.new(2+d,8+d,15+d)
			end
		end
	else
	
	end
end

function timeCycle.draw()
	if map.scrollY <= 272 then
		local t = math.floor(timeCycle.timer:time() / 1000 )
		
		-- Soleil
		if (t >= 0 and t <= 264) or t >= 504 then
			local x = t
			if t >= 504 then
				x = t - 512
			end
			
			screen.blit(SCREEN_DOWN, x-8, 19-(map.scrollY/16)*2, timeCycle.img, 0, 0, 16, 16)
		end
		-- Lune
		if (t >= 248 and t <= 512) or t <= 8 then
			local x = t - 256
			if t <= 8 then
				x = 256 + t
			end
			
			screen.blit(SCREEN_DOWN, x-8, 19-(map.scrollY/16)*2, timeCycle.img, 16, 0, 16, 16)
		end
		
		
	end
end