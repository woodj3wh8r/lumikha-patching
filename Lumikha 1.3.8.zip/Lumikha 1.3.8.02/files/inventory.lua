-------------------------------------------------------------------------------
--  Lumikha
--  Copyright (C) 2011 Fantasix
--
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
-------------------------------------------------------------------------------

-- ****************** INVENTORY ****************** --
local MICROLUA_VERSION = 4
inventory = {}
function inventory.load()
	inventory.itemFrame = {}
	inventory.itemFrame.img = Image.load("images/gui.png", VRAM)

	inventory.selectedIndex = 1

	inventory.tab = {}

	for i = 1, 36 do
		inventory.tab[i] = {}
	end

	local file = io.open("saves/"..worldNumber.."/inventory.ftsx", "r")
	local line = file:read()
	local lineID = 1

	while line do
		if string.byte(string.sub(line, -1,-1)) == 13 or string.byte(string.sub(line, -1,-1)) == 10 then
			line = string.sub(line , 1, -2)
		end
		
		sta, sto, hex = string.find(line, "%-(%d+)")
		sta, sto, id = string.find(line, "(%d+)")
		
		if not hex then 
			hex = 1
		end
		
		if tonumber(id) > 0 then
			inventory.tab[lineID][1] = tonumber(id)
			inventory.tab[lineID][2] = tonumber(hex)
		end
		
		lineID = lineID + 1
		line = file:read()
	end

	io.close() 
end

function inventory.destroy()
	Image.destroy(inventory.itemFrame.img)
	inventory.itemFrame.img = nil
end

function inventory.addItem(id, hex, index, switch)
	local find = false
	local i = 1
	if not hex then hex = 1 end
	local tb = {}
	
	if data.tab[id] then
		if index and switch then
			find = true
			
			if inventory.tab[index][1] and (inventory.tab[index][1] ~= id or not data.tab[id].stack) then
				if not inventory.tab[switch][1] then -- On switch les deux
					local tmpID = inventory.tab[index][1]
					local tmpHex = inventory.tab[index][2]
					
					inventory.tab[index][1] = id
					inventory.tab[index][2] = hex
					
					inventory.tab[switch][1] = tmpID
					inventory.tab[switch][2] = tmpHex
				else -- On met celui sous le stylet � la place de l'autre, et on range l'autre
					local tmpID = inventory.tab[index][1]
					local tmpHex = inventory.tab[index][2]
					
					inventory.tab[index][1] = id
					inventory.tab[index][2] = hex
					
					id = tmpID
					hex = tmpHex
					find = false
					index = false
				end
			else
				find = false
			end
		end
		if index and not find then
			find = true
			if data.tab[id].stack then
				if inventory.tab[index][1] and inventory.tab[index][1] == id and inventory.tab[index][2] < data.tab[id].stack then
					inventory.tab[index][2] = inventory.tab[index][2] + hex
					hex = 0
					if inventory.tab[index][2] > data.tab[id].stack then
						hex = inventory.tab[index][2] - data.tab[id].stack
						inventory.tab[index][2] = data.tab[id].stack
						find = false
					end
				elseif not inventory.tab[index][1] then
					inventory.tab[index][1] = id
					inventory.tab[index][2] = hex
					hex = 0
					if inventory.tab[index][2] > data.tab[id].stack then
						hex = inventory.tab[index][2] - data.tab[id].stack
						inventory.tab[index][2] = data.tab[id].stack
						find = false
					end
				else
					find = false
				end
			elseif not inventory.tab[index][1] then
				inventory.tab[index][1] = id
				inventory.tab[index][2] = hex
				hex = 0
			else
				find = false
			end
		end
		
		if not find then -- On le range
			while i <= #inventory.tab and hex > 0 do
				if data.tab[id].stack then
					if inventory.tab[i][1] and inventory.tab[i][1] == id and inventory.tab[i][2] < data.tab[id].stack then
						inventory.tab[i][2] = inventory.tab[i][2] + hex
						hex = 0
						if inventory.tab[i][2] > data.tab[id].stack then
							hex = inventory.tab[i][2] - data.tab[id].stack
							inventory.tab[i][2] = data.tab[id].stack
						end
						table.insert(tb, i)
					elseif not inventory.tab[i][1] then
						inventory.tab[i][1] = id
						inventory.tab[i][2] = hex
						hex = 0
						if inventory.tab[i][2] > data.tab[id].stack then
							hex = inventory.tab[i][2] - data.tab[id].stack
							inventory.tab[i][2] = data.tab[id].stack
						end
						table.insert(tb, i)
					end
				elseif not inventory.tab[i][1] then
					inventory.tab[i][1] = id
					inventory.tab[i][2] = hex
					table.insert(tb, i)
					hex = 0
				end
				
				i = i + 1
			end
		end
	end
	return tb
end

function inventory.removeItem(index, nb)
	local nb = nb or 1
	if inventory.tab[index][1] then
		if data.tab[inventory.tab[index][1]].stack then
			inventory.tab[index][2] = inventory.tab[index][2] - nb 
			if inventory.tab[index][2] <= 0 then
				inventory.tab[index][1] = nil
				inventory.tab[index][2] = nil
			end
		else
			inventory.tab[index][1] = nil
			inventory.tab[index][2] = nil
		end
	end
end

function inventory.onMapAct()
	if Stylus.newPress then
		local sX = math.floor(Stylus.X/16)
		local sY = math.floor(Stylus.Y/16)
		
		if not char.isAtProximity(sX, sY) then
			if char.posY >= 4 then
				if Stylus.X > 43 and Stylus.X < 213 and Stylus.Y > 2 and Stylus.Y < 22 then
					inventory.selectedIndex = math.ceil((Stylus.X-43) / 19)
				--	Canvas.setAttr(inventory.itemFrame.selectedObj, ATTR_X1, (inventory.selectedIndex-1)*20)
				end
			else
				if Stylus.X > 43 and Stylus.X < 213 and Stylus.Y > 170 and Stylus.Y < 190 then
					inventory.selectedIndex = math.ceil((Stylus.X-43) / 19)
				--	Canvas.setAttr(inventory.itemFrame.selectedObj, ATTR_X1, (inventory.selectedIndex-1)*20)
				end
			end
		end
	end
	
	if Keys.newPress.R then
		if inventory.selectedIndex < 9 then
			inventory.selectedIndex = inventory.selectedIndex + 1
		else
			inventory.selectedIndex = 1
		end
		--Canvas.setAttr(inventory.itemFrame.selectedObj, ATTR_X1, (inventory.selectedIndex-1)*20)
	elseif Keys.newPress.L then
		if inventory.selectedIndex > 1 then
			inventory.selectedIndex = inventory.selectedIndex - 1
		else
			inventory.selectedIndex = 9
		end
		--Canvas.setAttr(inventory.itemFrame.selectedObj, ATTR_X1, (inventory.selectedIndex-1)*20)
	end
end

function inventory.onMapDraw()
	-- ITEM SQUARES
	if tonumber(string.sub(MICROLUA_VERSION, 1, 1)) == 4 then
		screen.setAlpha(50, 200)
    -- screen.setAlpha(50, screen.getAlpha())
	end
	if char.posY < 4 then
		screen.blit(SCREEN_DOWN, 43, 170, inventory.itemFrame.img, 0, 0, 172, 20)
		--Canvas.draw(SCREEN_DOWN, inventory.itemFrame.canvas, 38, 170)
	else
		screen.blit(SCREEN_DOWN, 43, 2, inventory.itemFrame.img, 0, 0, 172, 20)
		--Canvas.draw(SCREEN_DOWN, inventory.itemFrame.canvas, 38, 2)
	end
	
	-- ITEMS
	if tonumber(string.sub(MICROLUA_VERSION, 1, 1)) == 4 then
		screen.setAlpha(100)
	end
	
	for i = 0, 8 do
		if inventory.tab[i+1][1] then
			local qte = inventory.tab[i+1][2]
			if char.posY >= 4 then
				screen.blit(SCREEN_DOWN, 45+i*19, 4, data.items, data.tab[inventory.tab[i+1][1]].coord[1], data.tab[inventory.tab[i+1][1]].coord[2], 16, 16)
				local typeItem = data.tab[inventory.tab[i+1][1]].type
				if typeItem == "block" or typeItem == "item" then
					screen.print(SCREEN_DOWN, 45+i*19, 12, qte)
				end
			else
				screen.blit(SCREEN_DOWN, 45+i*19, 172, data.items, data.tab[inventory.tab[i+1][1]].coord[1], data.tab[inventory.tab[i+1][1]].coord[2], 16, 16)
				local typeItem = data.tab[inventory.tab[i+1][1]].type
				if typeItem == "block" or typeItem == "item" then
					screen.print(SCREEN_DOWN, 45+i*19, 180, qte)
				end
			end
		end
	end
	
	-- Curseur
	if char.posY < 4 then
		screen.blit(SCREEN_DOWN, 43+(inventory.selectedIndex - 1)*19, 170, inventory.itemFrame.img, 172, 0, 20, 20)
	else
		screen.blit(SCREEN_DOWN, 43+(inventory.selectedIndex - 1)*19, 2, inventory.itemFrame.img, 172, 0, 20, 20)
	end
end

function inventory.menuAct()
	local valid = false
	if Keys.newPress.Select then
		valid = true
	elseif Stylus.doubleClick then
		local sX = math.floor(Stylus.X/16)
		local sY = math.floor(Stylus.Y/16)
		
		if not char.isAtProximity(sX, sY) then
			valid = true
			if char.posY >= 4 then
				if Stylus.X > 43 and Stylus.X < 213 and Stylus.Y > 2 and Stylus.Y < 22 then
					valid = false
				end
			else
				if Stylus.X > 43 and Stylus.X < 213 and Stylus.Y > 170 and Stylus.Y < 190 then
					valid = false
				end
			end
		end
	end
	
	if valid then
		Controls.read()
		
		getPause(250)
		
		local inventoryImage = Image.load("images/inventory.png", VRAM)
		local invCanv = Canvas.new()
		
		for i = 0, 8 do
			if inventory.tab[i+1][1] then
				local qte = inventory.tab[i+1][2]
				inventory.tab[i+1][3] = Canvas.newImage(48+i*18, 155, data.items, data.tab[inventory.tab[i+1][1]].coord[1], data.tab[inventory.tab[i+1][1]].coord[2], 16, 16)
				
				
				local typeItem = data.tab[inventory.tab[i+1][1]].type
				if typeItem == "block" or typeItem == "item" then
					inventory.tab[i+1][4] = Canvas.newText(48+i*18, 163, qte)
				else
					inventory.tab[i+1][4] = Canvas.newText(48+i*18, 163, "")
				end
			else
				inventory.tab[i+1][3] = Canvas.newImage(48+i*18, 155, data.items, 0, 0, 16, 16)
				inventory.tab[i+1][4] = Canvas.newText(48+i*18, 163, "")
			end
			Canvas.add(invCanv, inventory.tab[i+1][3])
			Canvas.add(invCanv, inventory.tab[i+1][4])
		end
		
		for i = 9, 35 do
			local x1 = i - 9
			x2 = math.floor(x1/9)
			if inventory.tab[i+1][1] then
				local qte = inventory.tab[i+1][2]
				inventory.tab[i+1][3] = Canvas.newImage(48+x1*18-x2*162, 97+x2*18, data.items, data.tab[inventory.tab[i+1][1]].coord[1], data.tab[inventory.tab[i+1][1]].coord[2], 16, 16)
				
				local typeItem = data.tab[inventory.tab[i+1][1]].type
				if typeItem == "block" or typeItem == "item" then
					inventory.tab[i+1][4] = Canvas.newText(48+x1*18-x2*162, 105+x2*18, qte)
				else
					inventory.tab[i+1][4] = Canvas.newText(48+x1*18-x2*162, 105+x2*18, "")
				end
			else
				inventory.tab[i+1][3] = Canvas.newImage(48+x1*18-x2*162, 97+x2*18, data.items, 0, 0, 16, 16)
				inventory.tab[i+1][4] = Canvas.newText(48+x1*18-x2*162, 105+x2*18, "")
			end
			Canvas.add(invCanv, inventory.tab[i+1][3])
			Canvas.add(invCanv, inventory.tab[i+1][4])
		end
		
		--removeObj
		
		local prevPos = nil
		local underStylus = {0, 0}
		local craftResult = {0, 0}
		local tabCraft = {
						{0,0},
						{0,0},
						}
		local tabCraftQte = {
						{0,0},
						{0,0},
						}
		
		local function actualizeCraftRecipe()
			local tab = {}
			-- Copie de la table (Sinon retourne une putain d'erreur)
			for y = 1, #tabCraft do
				tab[y] = {}
				for x = 1, #tabCraft[y] do
					tab[y][x] = tabCraft[y][x]
				end
			end
			
			local craftPattern = getPattern(tab)
			
			local find = false
			for k, v in pairs(data.tab) do
				if v.pattern and v.pattern == craftPattern then
					craftResult[1] = k
					craftResult[2] = v.givenAmount
					find = true
					break
				end
			end
			
			if not find then
				craftResult[1] = 0
				craftResult[2] = 0
			end
		end
		
		local function showRemainItems()
			if rPT[1] then -- Tableau des endroits o� ont �t� stack�s les items restant
				for i = 1, #rPT do
					Canvas.setAttr(inventory.tab[rPT[i]][3], ATTR_X2, data.tab[inventory.tab[rPT[i]][1]].coord[1])
					Canvas.setAttr(inventory.tab[rPT[i]][3], ATTR_Y2, data.tab[inventory.tab[rPT[i]][1]].coord[2])
					
					local typeItem = data.tab[inventory.tab[rPT[i]][1]].type
					if typeItem == "block" or typeItem == "item" then
						Canvas.setAttr(inventory.tab[rPT[i]][4], ATTR_TEXT, inventory.tab[rPT[i]][2])
					else
						Canvas.setAttr(inventory.tab[rPT[i]][4], ATTR_TEXT, "")
					end
				end
			end
		end
		
		local quitMenu = false
		while not quitMenu do
			Controls.read()
			
			if Keys.newPress.Select then
				quitMenu = true
			elseif Stylus.doubleClick and underStylus[1] == 0 then
				local sX = Stylus.X
				local sY = Stylus.Y
				
				if not (sX >= 41 and sX <= 214 and sY >= 14 and sY <= 177) then
					quitMenu = true
				end
			end
			
			constantFunction()
			
			screen.blit(SCREEN_DOWN, 41, 14, inventoryImage)
			
			-- ******************** AFFICHAGE ******************** --

			Canvas.draw(SCREEN_DOWN, invCanv, 0, 0)	
			
				-- Table de craft 2*2
			for y = 1, 2 do
				for x = 1, 2 do
					if tabCraft[y][x] > 0 then
						local qte = tabCraftQte[y][x]
						screen.blit(SCREEN_DOWN, 92+(x-1)*18, 38+(y-1)*18, data.items, data.tab[tabCraft[y][x]].coord[1], data.tab[tabCraft[y][x]].coord[2], 16, 16)
						
						local typeItem = data.tab[tabCraft[y][x]].type
						if typeItem == "block" or typeItem == "item" then
							screen.print(SCREEN_DOWN, 74+x*18, 46+(y-1)*18, qte)
						end
					end
				end
			end
			
				-- R�sultat craft
			if craftResult[1] > 0 then
				local qte = craftResult[2]
				screen.blit(SCREEN_DOWN, 148, 48, data.items, data.tab[craftResult[1]].coord[1], data.tab[craftResult[1]].coord[2], 16, 16)
				
				local typeItem = data.tab[craftResult[1]].type
				if typeItem == "block" or typeItem == "item" then
					screen.print(SCREEN_DOWN, 148, 56, qte)
				end
			end		
			
			-- ******************** GESTION CRAFT ******************** --
			
			if Stylus.newPress and underStylus[1] == 0 then
				-- Rep�rage de la case
				local sX = Stylus.X
				local sY = Stylus.Y
				
				if sX >= 47 and sX <= 208 then
					if sY >= 154 and sY <= 171 then -- Barre du bas
						local indexInv = math.ceil((Stylus.X-47)/18)
						local idItem = inventory.tab[indexInv][1]
						if idItem then
							underStylus[1] = idItem
							underStylus[2] = 1
							prevPos = indexInv
							
							if Ambi.held.Down() then -- Si on appuie en bas, on prend le stack entier
								underStylus[2] = inventory.tab[indexInv][2]
							elseif Ambi.held.Right() or Ambi.held.Left() then
								underStylus[2] = math.ceil(inventory.tab[indexInv][2] / 2)
							end
							
							inventory.removeItem(indexInv, underStylus[2])
							if not inventory.tab[indexInv][1] then
								Canvas.setAttr(inventory.tab[indexInv][3], ATTR_X2, 0)
								Canvas.setAttr(inventory.tab[indexInv][3], ATTR_Y2, 0)
								Canvas.setAttr(inventory.tab[indexInv][4], ATTR_TEXT, "")
							else
								Canvas.setAttr(inventory.tab[indexInv][4], ATTR_TEXT, inventory.tab[indexInv][2])
							end
						end
					elseif sY >= 96 and sY <= 149 then -- Inventaire principal
						local indexInv = 9 + math.ceil((Stylus.X-47)/18) + math.floor((Stylus.Y-96)/18)*9
						local idItem = inventory.tab[indexInv][1]
						if idItem then
							underStylus[1] = idItem
							underStylus[2] = 1
							prevPos = indexInv
							
							if Ambi.held.Down() then -- Si on appuie en bas, on prend le stack entier
								underStylus[2] = inventory.tab[indexInv][2]
							elseif Ambi.held.Right() or Ambi.held.Left() then
								underStylus[2] = math.ceil(inventory.tab[indexInv][2] / 2)
							end
							
							inventory.removeItem(indexInv, underStylus[2])
							if not inventory.tab[indexInv][1] then
								Canvas.setAttr(inventory.tab[indexInv][3], ATTR_X2, 0)
								Canvas.setAttr(inventory.tab[indexInv][3], ATTR_Y2, 0)
								Canvas.setAttr(inventory.tab[indexInv][4], ATTR_TEXT, "")
							else
								Canvas.setAttr(inventory.tab[indexInv][4], ATTR_TEXT, inventory.tab[indexInv][2])
							end
						end
					elseif sY >= 37 and sY <= 72 and sX >= 91 and sX <= 126 then -- Table de craft
						local craftX = math.ceil((Stylus.X-91)/18)
						local craftY = math.ceil((Stylus.Y-37)/18)
						local idItem = tabCraft[craftY][craftX]
						
						if idItem > 0 then
							underStylus[1] = idItem
							underStylus[2] = 1
							
							if Ambi.held.Down() then -- Si on appuie en bas, on prend le stack entier
								underStylus[2] = tabCraftQte[craftY][craftX]
							elseif Ambi.held.Right() or Ambi.held.Left() then
								underStylus[2] = math.ceil(tabCraftQte[craftY][craftX] / 2)
							end
							
							tabCraftQte[craftY][craftX] = tabCraftQte[craftY][craftX] - underStylus[2]
							if tabCraftQte[craftY][craftX] == 0 then
								tabCraft[craftY][craftX] = 0
								actualizeCraftRecipe()
							end							
						end
					elseif sY >= 48 and sY <= 63 and sX >= 148 and sX <= 163 then -- R�sultat de craft
						local idItem = craftResult[1]
						
						if idItem > 0 then
							underStylus[1] = idItem
							underStylus[2] = craftResult[2]
							
							local actualize = false
							for y = 1, #tabCraft do
								for x = 1, #tabCraft[y] do
									if tabCraftQte[y][x] > 0 then
										tabCraftQte[y][x] = tabCraftQte[y][x] - 1
										
										if tabCraftQte[y][x] == 0 then
											actualize = true
											tabCraft[y][x] = 0
										end
									end
								end
							end
							if actualize then
								actualizeCraftRecipe()
							end
						end
					end
				end
			elseif Stylus.released and underStylus[1] > 0 then
				local sX = Stylus.X
				local sY = Stylus.Y
				local indexInv = nil
				local toCraftTable = false
				local craftX = 0
				local craftY = 0
				
				if sX >= 47 and sX <= 208 then
					if sY >= 154 and sY <= 171 then
						indexInv = math.ceil((Stylus.X-47)/18)
					elseif sY >= 96 and sY <= 149 then
						indexInv = 9 + math.ceil((Stylus.X-47)/18) + math.floor((Stylus.Y-96)/18)*9
					elseif sY >= 37 and sY <= 72 and sX >= 91 and sX <= 126 then -- Table de craft
						toCraftTable = true
						
						craftX = math.ceil((sX-90)/18)
						craftY = math.ceil((sY-36)/18)
					end
				end
				
				if toCraftTable then
					if tabCraft[craftY][craftX] > 0 then
						local typeItem = data.tab[tabCraft[craftY][craftX]].type
						if tabCraft[craftY][craftX] == underStylus[1] and (typeItem == "block" or typeItem == "item") then
							tabCraftQte[craftY][craftX] = tabCraftQte[craftY][craftX] + underStylus[2]
							
							underStylus[2] = 0
							
							if tabCraftQte[craftY][craftX] > data.tab[tabCraft[craftY][craftX]].stack then
								underStylus[2] = tabCraftQte[craftY][craftX] - data.tab[tabCraft[craftY][craftX]].stack
								tabCraftQte[craftY][craftX] = data.tab[tabCraft[craftY][craftX]].stack
								
								rPT = inventory.addItem(underStylus[1], underStylus[2], tabCraft[craftY][craftX])
								showRemainItems()
							end
						else
							rPT = inventory.addItem(underStylus[1], underStylus[2])
							showRemainItems()
						end
					else
						tabCraft[craftY][craftX] = underStylus[1]
						tabCraftQte[craftY][craftX] = underStylus[2]
						actualizeCraftRecipe()
					end
				else
					rPT = inventory.addItem(underStylus[1], underStylus[2], indexInv, prevPos)
					
					if indexInv then
						Canvas.setAttr(inventory.tab[indexInv][3], ATTR_X2, data.tab[inventory.tab[indexInv][1]].coord[1])
						Canvas.setAttr(inventory.tab[indexInv][3], ATTR_Y2, data.tab[inventory.tab[indexInv][1]].coord[2])
						
						local typeItem = data.tab[inventory.tab[indexInv][1]].type
						if typeItem == "block" or typeItem == "item" then
							Canvas.setAttr(inventory.tab[indexInv][4], ATTR_TEXT, inventory.tab[indexInv][2])
						else
							Canvas.setAttr(inventory.tab[indexInv][4], ATTR_TEXT, "")
						end
						
						if prevPos and inventory.tab[prevPos][1] then
							Canvas.setAttr(inventory.tab[prevPos][3], ATTR_X2, data.tab[inventory.tab[prevPos][1]].coord[1])
							Canvas.setAttr(inventory.tab[prevPos][3], ATTR_Y2, data.tab[inventory.tab[prevPos][1]].coord[2])
							
							local typeItem = data.tab[inventory.tab[prevPos][1]].type
							if typeItem == "block" or typeItem == "item" then
								Canvas.setAttr(inventory.tab[prevPos][4], ATTR_TEXT, inventory.tab[prevPos][2])
							else
								Canvas.setAttr(inventory.tab[prevPos][4], ATTR_TEXT, "")
							end
						end
					end	
					
					showRemainItems()
						
				end
				
				underStylus[1] = 0
				underStylus[2] = 0
				
				prevPos = nil
			elseif underStylus[1] > 0 then
				screen.blit(SCREEN_DOWN, Stylus.X - 8, Stylus.Y - 8, data.items, data.tab[underStylus[1]].coord[1], data.tab[underStylus[1]].coord[2], 16, 16)
				if underStylus[2] and underStylus[2] > 0 then
					screen.print(SCREEN_DOWN, Stylus.X - 8, Stylus.Y, underStylus[2])
				end
			end
			
			-- ******************** ******************** --
			screen.print(SCREEN_UP, 0, 184, NB_FPS)
			
			render()
		end
		getPause(250)
		
		for y =1, #tabCraft do
			for x=1, #tabCraft[y] do
				if tabCraft[y][x] > 0 then
					inventory.addItem(tabCraft[y][x], tabCraftQte[y][x])
				end
			end
		end
		
		getPause(250)
		
		Canvas.destroy(invCanv)
		invCanv = nil
		Image.destroy(inventoryImage)
		inventoryImage = nil
		
		collectgarbage("collect")
		
		getPause(250)
		
		Controls.read()
	end
end