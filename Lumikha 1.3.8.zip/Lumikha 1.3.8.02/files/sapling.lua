-------------------------------------------------------------------------------
--  Lumikha
--  Copyright (C) 2011 Fantasix
--
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
-------------------------------------------------------------------------------

-- Sapling

sapling = {}

function sapling.load()
	sapling.list = {}
	
	local file = io.open("saves/"..worldNumber.."/sapling.ftsx", "r")
	local line = file:read()

	while line do
		if string.byte(string.sub(line, -1,-1)) == 13 or string.byte(string.sub(line, -1,-1)) == 10 then
			line = string.sub(line , 1, -2)
		end
		
		limit = nil
		
		sta, sto, id, x, y, timer = string.find(line, "(.+)|(.+)|(.+)|(.+)|(.+)")
		
		id = tonumber(id)
		x = tonumber(x)
		y = tonumber(y)
		timer = tonumber(timer)
		lastCheck =  tonumber(lastCheck)
		
		table.insert(sapling.list, id, {
			x = x, 
			y = y, 
			timer = Timer.new(timer),
			lastCheck = Timer.new(lastCheck),
		})
		
		line = file:read()
	end

	io.close() 
	
	for k, v in pairs(sapling.list) do
		if v.timer:time() < 512000 then
			v.timer:start()
		end
		if v.lastCheck:time() > 0 then
			v.lastCheck:start()
		end
	end
end

function sapling.destroy()
	sapling.list = nil
end

function sapling.new(x, y)
	table.insert(sapling.list, {x = x, y = y, timer = Timer.new(), lastCheck = Timer.new()})
end

function sapling.getID(x, y)
	for k, v in pairs(sapling.list) do
		if v.x == x and v.y == y then
			return k
		end
	end
	return -1
end

function sapling.remove(x, y)
	sapling.list[sapling.getID(x, y)] = nil
end

function sapling.check()
	for k, v in pairs(sapling.list) do
		local t = v.timer:time()
		if t == 0 and not v.timer:isRunning() then
			v.timer:start()
		elseif t >= 512000 then 
			local tT = math.floor(timeCycle.timer:time() / 1000 )
			if tT >= 8 and tT <= 248 then -- Daytime
				if v.lastCheck:time() == 0 or v.lastCheck:time() >= 10000 then
					local grow = false
					local failure = false
					if math.random(1, 100) <= 5 then
						grow = true
						failure = not growTree(v.x, v.y)
					end
					if grow then
						sapling.remove(v.x, v.y)
						if failure then
							ScrollMap.setTile(map.scrollMap, v.x, v.y, 101)
						end
					else
						v.lastCheck:reset()
						v.lastCheck:start()
					end
				end
			end
		end
	end
end