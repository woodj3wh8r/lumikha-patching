-------------------------------------------------------------------------------
--  Lumikha
--  Copyright (C) 2011 Fantasix
--
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
-------------------------------------------------------------------------------

function saveConfig()
	local file = io.open("saves/config.ftsx","w")
	local line = ""
	
	for k, v in pairs(OPTION) do
		line = line..k..":"..v.."\n"
	end
	
	if string.byte(string.sub(line, -1,-1)) == 13 or string.byte(string.sub(line, -1,-1)) == 10 then
		line = string.sub(line , 1, -2)
	end
	
	file:write(line)
	
	io.close(file)
	
	file = nil
end

function screen.centerPrint(scr, y, str, c)
	if not c then c = Color.new(31,31,31) end
	
	screen.print(scr, 128-#str*3, y, str, c)
end

button = {}
function button.new(lib, x1, y1, wid, fontC, backC, darkC, textCenter)
	local toRet = {}
	local canv = Canvas.new()
	local y2 = y1 + 2 + 8 + 4
	
	if not x1 and not wid then
		x1 = 128 - math.floor((4 + #lib*6 + 4) / 2)
	elseif not x1 then
		x1 = 128 -  math.floor(wid / 2)
	end
	
	if not wid then 
		textCenter = nil
		x2 = x1 + 4 + #lib*6 + 4 -- X1 + Bordure + Longueur texte + Bordure
	else
		x2 = x1 + wid
	end
	
	if not fontC then
		fontC = Color.new(31,31,31)
	end
	
	if not backC then
		backC = Color.new(20,20,20)
	end
	
	if not darkC then
		darkC = Color.new(10,10,10)
	end
	
	Canvas.add(canv, Canvas.newFillRect(x1, y1, x2, y2, backC))
	Canvas.add(canv, Canvas.newRect(x1+1, y1+1, x2, y2, Color.new(31,31,31)))
	Canvas.add(canv, Canvas.newRect(x1, y1, x2, y2, darkC))
	
	if textCenter then
		local txtS = #lib*6
		Canvas.add(canv, Canvas.newText(x1 + 4 + math.floor(((x2-x1-8)-txtS)/2), y1 + 4, lib, darkC))
		Canvas.add(canv, Canvas.newText(x1 + 3 + math.floor(((x2-x1-8)-txtS)/2), y1 + 3, lib, fontC))
	else
		Canvas.add(canv, Canvas.newText(x1 + 4, y1 + 4, lib, darkC))
		Canvas.add(canv, Canvas.newText(x1 + 3, y1 + 3, lib, fontC))
	end
	
	local toRet = {
		libelle = lib,
		x1 = x1,
		y1 = y1,
		x2 = x2,
		y2 = y2,
		display = false,
		canvas = canv
	}
	
	return toRet
end

function button.draw(b, scr)
	b.display = true
	Canvas.draw(scr, b.canvas, 0, 0)
end

function button.press(b)
	if b.display and Stylus.newPress and Stylus.X >= b.x1 and Stylus.X <= b.x2 and Stylus.Y >= b.y1 and Stylus.Y <= b.y2 then
		return true
	end
	return false
end

function button.destroy(b)
	Canvas.destroy(b.canvas)
	return nil
end

function getPause(t)
	startTimer = Timer.new()
	startTimer:start()

	while startTimer:time() < t do

	end
	
	startTimer:reset()
	startTimer = nil
end

function getPattern(c)
	local sizeC = #c
	local sizeX = 0
	local issetOnCol = {}
	local sizeY = 0
	local issetOnRow = {}
	
	local minX = sizeC
	local maxX = 1
	local minY = sizeC
	local maxY = 1
	
	-- On d�fini ici la largeur et la hauteur du craft
	for y = 1, #c do
		local inThisRow = 0
		for x = 1, #c[y] do
			if c[y][x] > 0 then
				inThisRow = inThisRow + 1
				
				if x > maxX then
					maxX = x
				end
				if x < minX then
					minX = x
				end
				
				issetOnCol[x] = true
			end
		end
		if inThisRow > 0 then
			issetOnRow[y] = true
			if y > maxY then
				maxY = y
			end
			if y < minY then
				minY = y
			end
		end
	end
	
	sizeX = maxX - minX + 1
	sizeY = maxY - minY + 1
	
	
	-- Suppression des lignes :
	if sizeC - sizeY > 0 then -- Sinon, on a pas de lignes � supprimer
		for i = sizeC, 1, -1 do
			if not issetOnRow[i] then
				table.remove(c, i)
			end
		end
	end
	
	-- Suppression des colonnes :
	if sizeC - sizeX > 0 then -- Sinon, on a pas de colonnes � supprimer
		for i = sizeC, 1, -1 do
			if not issetOnCol[i] then
				for u = 1, #c do -- On parcours les lignes pour enlever les colonnes
					table.remove(c[u], i)
				end
			end
		end
	end
	
	local s = ""
	for y=1, #c do
		for x = 1, #c[y] do
			s = s..c[y][x]
			if x < #c[y] then
				s = s.."|"
			end
		end
		if y < #c then
			s = s.."-"
		end
	end
	
	return s
end

-- Fonction de g�n�ration d'arbres
function growTree(x, y)
		-- Trois types d'arbres 
		local treeTypes = {
			[1] = {{1, 0, 0}, {1, 0,-1}, {98, 0,-2}, {98, -1,-1}, {98, 1,-1}},
			[2] = {{1, 0, 0}, {1, 0,-1}, {1, 0,-2}, {98, 0,-3}, {98, -1,-2}, {98 ,1,-2}},
			[3] = {{1, 0, 0}, {1, 0,-1}, {1, 0,-2}, {1, 0,-3}, {1, 0,-4}, {98, 0,-5}, {1, -1,-3}, {98, -1,-4}, {1, 1,-3}, {98, 1,-4}, {98, -2,-3}, {98, 2,-3}}
		}
		local set = false
		local choosenType = math.random(1, 10)
		if choosenType <= 2 then 
			choosenType = 1 
		elseif choosenType <= 7 then 
			choosenType = 2
		else
			choosenType = 3
		end
		
		while not set and choosenType > 0 do
			local valid = true
			for k, v in pairs(treeTypes[choosenType]) do
				if y+v[3] > 0 and x+v[2] > 0 and x+v[2] < 64 then
					if ScrollMap.getTile(map.scrollMap, x+v[2], y+v[3]) > 0 then
						if not (v[2] == 0 and v[3] == 0 and ScrollMap.getTile(map.scrollMap, x+v[2], y+v[3]) == 97) then
							valid = false
							break
						end
					end
				else
					valid = false
					break
				end
			end
			
			if valid then
				for k, v in pairs(treeTypes[choosenType]) do
					ScrollMap.setTile(map.scrollMap, x+v[2], y+v[3], v[1])
				end
				set = true
			else
				choosenType = choosenType - 1
			end
		end
		
		if set then
			return true
		end
		return false
		
end

function constantFunction()
	furnace.act()
	timeCycle.act()
	sapling.check()
end

-- Touches gaucher / droitier
Ambi = {
	newPress = {},
	held = {}
}
Ambi.newPress.Up = function()
	if Keys.newPress.X or Keys.newPress.Up then
		return true
	end
	return false
end
Ambi.newPress.Down = function()
	if Keys.newPress.B or Keys.newPress.Down then
		return true
	end
	return false
end
Ambi.newPress.Left = function()
	if Keys.newPress.Y or Keys.newPress.Left then
		return true
	end
	return false
end
Ambi.newPress.Right = function()
	if Keys.newPress.A or Keys.newPress.Right then
		return true
	end
	return false
end

Ambi.held.Up = function()
	if Keys.held.X or Keys.held.Up then
		return true
	end
	return false
end
Ambi.held.Down = function()
	if Keys.held.B or Keys.held.Down then
		return true
	end
	return false
end
Ambi.held.Left = function()
	if Keys.held.Y or Keys.held.Left then
		return true
	end
	return false
end
Ambi.held.Right = function()
	if Keys.held.A or Keys.held.Right then
		return true
	end
	return false
end