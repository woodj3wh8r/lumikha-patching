-------------------------------------------------------------------------------
--  Lumikha
--  Copyright (C) 2011 Fantasix
--
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
-------------------------------------------------------------------------------

function generate(wN)
	tab = {}
	mWid = 256
	
	for y = 1, 64 do
		tab[y] = {}
		for x = 1, mWid do
			tab[y][x] = 0
		end
	end
	
	local function growOre(Sx, Sy, oreType)
		local oreDepositSize = {
			[16] = {2, 5}, -- Coal
			[17] = {2, 3}, -- Iron
			[18] = {1, 3}, -- Gold
			[19] = {1, 2}, -- Diamond
		}
		local oreSettingPos = {
			{-1,-1},
			{-1, 0},
			{-1, 1},
			{0, -1},
			{0, 0},
			{0, 1},
			{1, -1},
			{1, 0},
			{1, 1},
		}
		
		local nbOfOre = math.random(oreDepositSize[oreType][1], oreDepositSize[oreType][2])
		local oreSet = 0
		local nbPossibility = 9
		
		while nbPossibility > 0 and oreSet < nbOfOre and #oreSettingPos > 0 do
			local currentCheck = math.random(1, #oreSettingPos)
			local x = oreSettingPos[currentCheck][1]
			local y = oreSettingPos[currentCheck][2]
			
			if Sx+x > 0 and Sx+x <= mWid and tab[Sy+y][Sx+x] == 2 then
				tab[Sy+y][Sx+x] = oreType
				oreSet = oreSet + 1
			end
			
			table.remove(oreSettingPos, currentCheck)
		end
	end
	
	local function growTreeGeneration(x, y)
		-- Trois types d'arbres 
		local treeTypes = {
			[1] = {{1, 0, 0}, {1, 0,-1}, {98, 0,-2}, {98, -1,-1}, {98, 1,-1}},
			[2] = {{1, 0, 0}, {1, 0,-1}, {1, 0,-2}, {98, 0,-3}, {98, -1,-2}, {98 ,1,-2}},
			[3] = {{1, 0, 0}, {1, 0,-1}, {1, 0,-2}, {1, 0,-3}, {1, 0,-4}, {98, 0,-5}, {1, -1,-3}, {98, -1,-4}, {1, 1,-3}, {98, 1,-4}, {98, -2,-3}, {98, 2,-3}}
		}
		local set = false
		local choosenType = math.random(1, 10)
		if choosenType <= 2 then 
			choosenType = 1 
		elseif choosenType <= 7 then 
			choosenType = 2
		else
			choosenType = 3
		end
		
		while not set and choosenType > 0 do
			local valid = true
			for k, v in pairs(treeTypes[choosenType]) do
				if y+v[3] > 0 and x+v[2] > 0 and x+v[2] < mWid then
					if tab[y+v[3]][x+v[2]] > 0 or (k == 1 and tab[y+v[3]][x+v[2]] == 97) then
						valid = false
						break
					end
				else
					valid = false
					break
				end
			end
			
			if valid then
				for k, v in pairs(treeTypes[choosenType]) do
					tab[y+v[3]][x+v[2]] = v[1]
				end
				set = true
			else
				choosenType = choosenType - 1
			end
		end
		
		if set then
			return true
		end
		return false
	end
	
	-- R�partition des biomes :
	
	dofile("files/biomes.lua")
	
	allocateBiomes(mWid)
	
	-- Cr�ation des biomes
	for i = 1, #biomesList do
		biomesTab[biomesList[i]].func((i-1)*16, i*16)
		getPause(500)
	end	
	
	-- M�lange inter-couche
	getPause(500)
	
	for y = 32, 41 do
		for x = 1, mWid do
			if math.random(1,y-30) == 1 then
				tab[y][x] = 3
			end
		end
	end
	
	-- Ajout des gisements
	getPause(500)

	local minOreLayer = {
		[16] = {32, 3},
		[17] = {40, 3},
		[18] = {50, 2},
		[19] = {54, 2},
	}
	
	for y = 32, 63 do
		for x = 1, mWid do
			if tab[y][x] == 2 then
				for k, v in pairs(minOreLayer) do -- On test chaque gisement
					if y >= v[1] and math.random(1, 150) <= v[2] then
						growOre(x, y, k)
					end
				end
			end
		end
	end
	
	-- Gestion des biomes
	
	
	
	-- Mise en place des arbres
	getPause(500)
	
	local treePos = {}
	for y = 2, 25 do
		for x = 1, mWid do
			local tryToSet = true
			for i = -3, 3 do
				if treePos[x+i] then
					tryToSet = false
					break
				end
			end
			if tryToSet then
				local blockID = tab[y][x]
				if blockID == 4 then
					if math.random(1, 2) == 1 then
						if growTreeGeneration(x, y - 1) then
							treePos[x] = true
						end
					end
				end
			end
		end
	end
		
	-- Map luminosit�
	
	getPause(1000)
		
	tabTr = {}
	-- Remplissage tableau avec les couches de base
	local tCheck = {
		{x = -1, y = 0},
		{x = 1, y = 0},
		{x = 0, y = -1},
		{x = 0, y = 1},
		{x = -1, y = -1},
		{x = -1, y = 1},
		{x = 1, y = -1},
		{x = 1, y = 1},
		{x = -2, y = 0},
		{x = 2, y = 0},
		{x = 0, y = -2},
		{x = 0, y = 2},
	}
	for y = 1, 64 do
		tabTr[y] = {}
		for x = 1, mWid do
			local shadLevel = 2
			
			if tab[y][x] > 0 then
				local dist = 3
				for k, v in ipairs(tCheck) do
					if y+v.y <= 64 and y+v.y >= 1 and x+v.x >= 1 and x + v.x <= mWid then
						if tab[y+v.y][x+v.x] == 0 then
							if k <= 4 then
								dist = 1
							else
								dist = 2
							end
						end
					end
					
					if dist < 3 then
						shadLevel = dist - 1
						break
					end
				end
			else
				shadLevel = 0
			end
			tabTr[y][x] = shadLevel
		end
	end
		
	-- ****************************** --
	-- ***** Sauvegarde de la map ***** --
	-- ****************************** --
	
	getPause(1000)
	
	System.makeDirectory("saves/"..wN)
	-- MAP
	local file = io.open("saves/"..wN.."/map.map", "w")
	for y = 1, 64 do
		local line = ""
		for x = 1, mWid do
			line = line..tab[y][x].."|"
		end
		line = line.."\n"
		if y == 64 then
			line = string.sub(line, 1, -2)
		end
		file:write(line)
	end
	io.close(file)
	file = nil
	
	-- CHAR
	local file = io.open("saves/"..worldNumber.."/misc.ftsx","w")
	local charTab = {
		1,
		1,
		0,
		0,
		8000,
	}
	for i = 1, #charTab do
		local line = charTab[i].."\n"
		
		if i == #charTab then
			line = string.sub(line, 1, -2)
		end
		
		file:write(line)
	end
	io.close(file)
	file = nil
	
	-- INVENTORY
	local file = io.open("saves/"..worldNumber.."/inventory.ftsx","w")
	for i = 1, 36 do
		file:write("0\n")
	end
	io.close(file)
	file = nil
	
	-- Sapling

	local file = io.open("saves/"..worldNumber.."/sapling.ftsx","w")
	file:write("")
	io.close(file)
	file = nil
	
	-- Furnaces

	local file = io.open("saves/"..worldNumber.."/furnace.ftsx","w")
	file:write("")
	io.close(file)
	file = nil
	
	-- Chest

	local file = io.open("saves/"..worldNumber.."/chest.ftsx","w")
	file:write("")
	io.close(file)
	file = nil
	
	getPause(1000)
		
	local file = io.open("saves/"..worldNumber.."/light.map", "w")
	for y = 1, 64 do
		local line = ""
		for x = 1, mWid do
			line = line..tabTr[y][x].."|"
		end
		line = line.."\n"
		if y == 64 then
			line = string.sub(line, 1, -2)
		end
		file:write(line)
	end
	io.close(file)
	file = nil
	tab = nil
	tabTr = nil
end
generate(worldNumber)

generate = nil

collectgarbage("collect")