-------------------------------------------------------------------------------
--  Lumikha
--  Copyright (C) 2011 Fantasix
--
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.

-- note from galaxzeey as 02/02/2024 10:43 am est spanish has been added by me
-------------------------------------------------------------------------------

language = {}
language[1] = {
	lib = "francais",
	["creatNewW"] = "Cr�er un nouveau monde",
	["quit"] = "Quitter",
	["option"] = "Options",
	["selectWorld"] = "Selectionner un monde",
	["goBack"] = "Retour",
	["chooseLanguage"] = "Choisissez votre langue",
	["world"] = "Monde",
	["loading"] = "Chargement",
	["saving"] = "Sauvegarde",

}

language[0] = {
	lib = "english",
	["creatNewW"] = "Create a new world",
	["quit"] = "Quit",
	["option"] = "Options",
	["selectWorld"] = "Select a world",
	["goBack"] = "Back",
	["chooseLanguage"] = "Choose your language",
	["world"] = "World",
	["loading"] = "Loading",
	["saving"] = "Saving",

}

language[2] = {
	lib = "deutsch",
	["creatNewW"] = "Erstellen einer neuen Welt",
	["quit"] = "Verlassen",
	["option"] = "Optionen",
	["selectWorld"] = "W�hlen eine Welt",
	["goBack"] = "Zur�ck",
	["chooseLanguage"] = "W�hlen Sie Ihre Sprache",
	["world"] = "Welt",
	["loading"] = "Lade",
	["saving"] = "Anmeldung",

}

language[3] = {
  lib = "espa�ol",
  ["creatNewW"] = "Crear un nuevo mundo",
  ["quit"] = "Salir",
  ["option"] = "Opciones",
  ["selectWorld"] = "Seleccionar un mundo",
  ["goBack"] = "Volver",
  ["chooseLanguage"] = "Elija su idioma",
  ["world"] = "Mundo",
  ["loading"] = "Cargando",
  ["saving"] = "Guardando",
  
}
--	[""] = "",
