-------------------------------------------------------------------------------
--  Lumikha
--  Copyright (C) 2011 Fantasix
--
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
-------------------------------------------------------------------------------

getPause(500)

data.load()

getPause(500)

char.load()

getPause(500)

inventory.load()

getPause(500)

map.load()

getPause(500)

furnace.load()

chest.load()

timeCycle.load()

sapling.load()

dofile("mods/modLoader.lua")
while not Keys.newPress.Start do
	Controls.read()
	
	timeCycle.act()
	
	sapling.check()
	
	map.draw()
	
	map.lightMapDraw()
	
	char.move()
	
	char.dig()
	
	char.draw()	
		
	char.setBlock()
	
	char.act()
	
	inventory.onMapAct()
	
	inventory.onMapDraw()
	
	inventory.menuAct()
	
	furnace.act(true)
	
	screen.print(SCREEN_UP, 0, 184, NB_FPS)
	screen.print(SCREEN_UP, 8, 8, "Lumikha v."..VERSION.." par Fantasix")
		
	-- Gestion des mods
	for k, v in pairs(MODS_TAB.loopMods) do
		v()
	end
	
	render()
end

timeCycle.timer:stop()

-- Gestion des mods
for k, v in pairs(MODS_TAB.endMods) do
	v()
end

local endTimer = Timer.new()
endTimer:start()
-- Sauvegarde ...
while endTimer:time() < 2000 do
	screen.print(SCREEN_DOWN, 4, 4, language[OPTION.lang].saving.." ...")
	
	render()
end
endTimer = nil

-- Sauvegarde miscancelous

local file = io.open("saves/"..worldNumber.."/misc.ftsx","w")
local tab = {
	char.posX,
	char.posY,
	map.scrollX,
	map.scrollY,
	timeCycle.timer:time()
}
for i = 1, #tab do
	local line = tab[i].."\n"
	
	if i == #tab then
		line = string.sub(line, 1, -2)
	end
	
	file:write(line)
end
io.close(file)
file = nil

-- Sauvegarde de l'inventaire

local file = io.open("saves/"..worldNumber.."/inventory.ftsx","w")

for i = 1, #inventory.tab do
	local line = "0\n"
	if inventory.tab[i][1] then
		line = inventory.tab[i][1].."-"..inventory.tab[i][2].."\n" 
	end
	if i == #inventory.tab then
		line = string.sub(line, 1, -2)
	end
	file:write(line)
end
io.close(file)
file = nil

-- Sauvegarde des sapling

local file = io.open("saves/"..worldNumber.."/sapling.ftsx","w")
local i = #sapling.list
for k, v in pairs(sapling.list) do
	local line = k.."|"..v.x.."|"..v.y.."|"..v.timer:time().."|"..v.lastCheck:time()
		
	line = line.."\n"
	i = i - 1
	if i == 0 then
		line = string.sub(line, 1, -2)
	end
	file:write(line)
end
io.close(file)
file = nil

-- Sauvegarde des furnaces

local file = io.open("saves/"..worldNumber.."/furnace.ftsx","w")
local i = #furnace.list
for k, v in pairs(furnace.list) do
	local line = k.."|"..v.x.."|"..v.y.."|"..v.fuel.id.."|"..v.fuel.qte.."|"..v.item.id.."|"..v.item.qte.."|"..v.result.id.."|"..v.result.qte.."|"..v.timer:time().."|"..v.limit
		
	line = line.."\n"
	i = i - 1
	if i == 0 then
		line = string.sub(line, 1, -2)
	end
	file:write(line)
end
io.close(file)
file = nil

-- Sauvegarde des coffres

local file = io.open("saves/"..worldNumber.."/chest.ftsx","w")
local i = #chest.list
for k, v in pairs(chest.list) do
	local line = "chest:"..k.."|"..v.x.."|"..v.y
		
	line = line.."\n"
	
	for p = 1, 27 do
		if v.items[p].id then
			line = line.."item:"..k.."|"..p.."|"..v.items[p].id.."|"..v.items[p].hex.."\n"
		end
	end
	
	i = i - 1
	if i == 0 then
		line = string.sub(line, 1, -2)
	end
	file:write(line)
end
io.close(file)
file = nil

-- Sauvegarde de la map

local tab = {}
for y = 0 , map.hei - 1 do
	local line = ""
	for x = 0, map.wid - 1 do
		line = line..ScrollMap.getTile(map.scrollMap , x , y).."|"
	end
	line = line.."\n"
	
	if y == map.hei - 1 then
		line = string.sub(line, 1, -2)
	end
	table.insert(tab, line)
	
end

local file = io.open(map.filePath,"w")
for i = 1, #tab do
	file:write(tab[i])
end
io.close(file)
file = nil
tab = nil

-- Sauvegarde de la LightMap

local tab = {}
for y = 0 , map.hei - 1 do
	local line = ""
	for x = 0, map.wid - 1 do
		line = line..ScrollMap.getTile(map.lightMap , x , y).."|"
	end
	line = line.."\n"
	
	if y == map.hei - 1 then
		line = string.sub(line, 1, -2)
	end
	table.insert(tab, line)
end

local file = io.open("saves/"..worldNumber.."/light.map","w")
for i = 1, #tab do
	file:write(tab[i])
end
io.close(file)
file = nil
tab = nil

-- ON SUPPRIME TOUT ! BWAAAAAAAAAAH
	furnace.destroy()
	map.destroy()
	char.destroy()
	inventory.destroy()
	data.destroy()
	chest.destroy()
	timeCycle.destroy()
	sapling.destroy()
	
	-- Canvas
		
	for k, v in pairs(MODS_TAB) do
		v = nil
	end
	MODS_TAB = nil
	
	collectgarbage("collect")
	
	dofile("files/title.lua")