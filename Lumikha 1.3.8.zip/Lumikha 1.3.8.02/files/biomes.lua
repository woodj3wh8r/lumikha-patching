-------------------------------------------------------------------------------
--  Lumikha
--  Copyright (C) 2011 Fantasix
--
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
-------------------------------------------------------------------------------

biomesTab = {}
biomesList = {}


function allocateBiomes(m)
	local function checkChunks()
		local vTab = {}
		local reDo = false
		for i = 1, #biomesTab do
			vTab[i] = false
		end
		for k, v in ipairs(biomesList) do
			if not vTab[v] then 
				vTab[v] = true
			end
		end
		for k, v in ipairs(vTab) do
			if not v then 
				biomesList[math.random(1, m/16)] = k
				reDo = true
			end
		end
		return reDo
	end
	
	for i = 1, m/16 do
		local r = math.random(1, 100)
		for k, v in pairs(biomesTab) do
			if r >= v.prob[1] and r <= v.prob[2] then
				table.insert(biomesList, k)
			end
		end
	end
	local bo = checkChunks()
	while bo do
		bo = checkChunks()
	end
	
end

-- DESERT
biomesTab[1] = {}
biomesTab[1].prob = {1, 20}
biomesTab[1].func = function(x1, x2)
	for y = 1, 64 do
		for x = x1, x2 do
			if y == 64 then
				tab[y][x] = 10
			elseif y >= 33 then
				tab[y][x] = 2
			elseif y >= 28 then
				tab[y][x] = 3
			elseif y >= 25 then
				tab[y][x] = 6
			else
				tab[y][x] = 0
			end
		end
	end
	
	for y = 24, 1, -1 do
		for x = x1, x2 do
			local blockID = tab[y][x]
			if blockID == 0 then
				local nbOfBlocks = 0
				
				if tab[y+1][x] > 0 then
					nbOfBlocks = nbOfBlocks + 1
				end
				
				if x - 1 >= 1 then
					if tab[y][x-1] > 0 then
						nbOfBlocks = nbOfBlocks + 5
					end
				end
				
				local proba = 0
				proba = proba + (nbOfBlocks * 10)
				if proba > 0 then 
					proba = proba + math.floor(y/10)*5
				end
				if math.random(1, 100) <= proba then
					tab[y][x] = 6
				end			
				
			end
		end
	end
	
	
	for x = x1, x2 do
		local find = false
		for y = 10, 24 do
			local blockID = tab[y][x]
			if blockID == 6 then
				find = true
			end
			if find and blockID == 0 then
				tab[y][x] = 6
			end
		end
	end
end

-- PLAINE

biomesTab[2] = {}
biomesTab[2].prob = {41, 100}
biomesTab[2].func = function(x1, x2)
	for y = 1, 64 do
		for x = x1, x2 do
			if y == 64 then
				tab[y][x] = 10
			elseif y >= 33 then
				tab[y][x] = 2
			elseif y == 25 then
				tab[y][x] = 4
			elseif y >= 25 then
				tab[y][x] = 3
			else
				tab[y][x] = 0
			end
		end
	end
	
	for y = 24, 1, -1 do
		for x = x1, x2 do
			local blockID = tab[y][x]
			if blockID == 0 then
				local nbOfBlocks = 0
				
				if tab[y+1][x] > 0 then
					nbOfBlocks = nbOfBlocks + 1
				end
				
				if x - 1 >= 1 then
					if tab[y][x-1] > 0 then
						nbOfBlocks = nbOfBlocks + 5
					end
				end
				
				local proba = 0
				proba = proba + (nbOfBlocks * 10)
				if proba > 0 then 
					proba = proba + math.floor(y/10)*5
				end
				if math.random(1, 100) <= proba then
					tab[y][x] = 4
				end			
				
			end
		end
	end
	
	-- On bouche les trous
	
	for x = x1, x2 do
		local find = false
		for y = 10, 24 do
			local blockID = tab[y][x]
			if blockID == 3 or blockID == 4 then
				find = true
			end
			if find and blockID == 0 then
				tab[y][x] = 3
			end
		end
	end
	
	-- On remplace les grass par des dirt
	
	for y = 1, 25 do
		for x = 1, mWid do
			local blockID = tab[y][x]
			if blockID == 4 then
				if y - 1 >= 1 then
					if tab[y - 1][x] > 0 then
						tab[y][x] = 3
					end
				end
			end
		end
	end
	
end

-- Montagne

biomesTab[3] = {}
biomesTab[3].prob = {21, 40}
biomesTab[3].func = function(x1, x2)
	for y = 1, 64 do
		for x = x1, x2 do
			if y == 64 then
				tab[y][x] = 10
			elseif y >= 33 then
				tab[y][x] = 2
			elseif y == 25 then
				tab[y][x] = 4
			elseif y >= 25 then
				tab[y][x] = 3
			else
				tab[y][x] = 0
			end
		end
	end
	
	for y = 24, 1, -1 do
		for x = x1, x2 do
			local blockID = tab[y][x]
			if blockID == 0 then
				local nbOfBlocks = 0
				
				if tab[y+1][x] > 0 then
					nbOfBlocks = nbOfBlocks + 1
				end
				
				if x - 1 >= 1 then
					if tab[y][x-1] > 0 then
						nbOfBlocks = nbOfBlocks + 1
					end
				end
				
				local proba = 0
				proba = proba + (nbOfBlocks * 30)
				if proba > 0 then 
					proba = proba + math.floor(y/10)*10
				end
				if math.random(1, 100) <= proba then
					tab[y][x] = 4
				end			
				
			end
		end
	end
	
	-- On bouche les trous
	
	for x = x1, x2 do
		local find = false
		for y = 10, 24 do
			local blockID = tab[y][x]
			if blockID == 3 or blockID == 4 then
				find = true
			end
			if find and blockID == 0 then
				tab[y][x] = 3
			end
		end
	end
	
	-- On remplace les grass par des dirt
	
	for y = 1, 25 do
		for x = 1, mWid do
			local blockID = tab[y][x]
			if blockID == 4 then
				if y - 1 >= 1 then
					if tab[y - 1][x] > 0 then
						tab[y][x] = 3
					end
				end
			end
		end
	end
end