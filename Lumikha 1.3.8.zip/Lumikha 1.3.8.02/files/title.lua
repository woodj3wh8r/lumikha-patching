-------------------------------------------------------------------------------
--  Lumikha
--  Copyright (C) 2011 Fantasix
--
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
-------------------------------------------------------------------------------

local function newWorld()
	System.changeDirectory("./saves")
	local files = System.listDirectory(System.currentDirectory())
	local nbW = 1
	
	local valid = false
	while not valid do
		valid = true
		for k, v in pairs(files) do
			if v.isDir and v.name ~= ".." and v.name ~= "." and tonumber(v.name) == nbW then
				valid = false
				break
			end
		end
		if not valid then
			nbW = nbW + 1
		end
	end
	
	files = nil
	System.changeDirectory("../")
	
	worldNumber = nbW
	
	mapGenerating = true
	
	quitMain = true
end

local function selectScreen()
	local quit = false
	previousBt = button.new(string.char(21).." "..language[OPTION.lang].goBack, 0, 0) -- Fleche + "Retour"
	
	System.changeDirectory("./saves")
	local files = System.listDirectory(System.currentDirectory())
	local worldTab = {}
	
	i = 0
	for k, v in pairs(files) do
		if v.isDir and v.name ~= ".." and v.name ~= "." then
			table.insert(worldTab, {id = tonumber(v.name), button = button.new(language[OPTION.lang].world.." "..v.name, nil, 32+i*16, 144, nil, nil, nil, true)})
			i = i + 1
		end
	end
	
	files = nil
	System.changeDirectory("../")
	
	while not quit do
		Controls.read()
			
		button.draw(previousBt, SCREEN_DOWN)
		
		for i = 1, #worldTab do
			button.draw(worldTab[i].button, SCREEN_DOWN)
		end
		
		for i = 1, #worldTab do
			if button.press(worldTab[i].button) then
				worldNumber = worldTab[i].id
				quit = true
				quitMain = true
			end
		end	
		
		if button.press(previousBt) then
			quit = true
		end
			
		render()
	end
	
	for i = 1, #worldTab do
		button.destroy(worldTab[i].button)
	end	
	
	worldTab = nil
	previousBt = button.destroy(previousBt)
	collectgarbage("collect")
	Controls.read()
end

local function optionScreen()
	local quit = false
	local previousBt = button.new(string.char(21).." "..language[OPTION.lang].goBack, 0, 0) -- Fleche + "Retour"
	
	local tabFlag = {} 
	
	local languageChanged = false
	
	local widImg = Image.width(flagImage)
	local x1Img = 128 - widImg / 2
	
	while not quit do
		Controls.read()
		
		button.draw(previousBt, SCREEN_DOWN)
		
		screen.centerPrint(SCREEN_DOWN, 32, language[OPTION.lang].chooseLanguage)
		
		screen.blit(SCREEN_DOWN, x1Img, 48, flagImage, 0, 0, widImg, 11)
		
		if Stylus.newPress and Stylus.Y >= 48 and Stylus.Y <= 58 and Stylus.X >= x1Img and Stylus.X <= x1Img + widImg then
			local newLang = math.floor((Stylus.X-x1Img)/16)
			if newLang ~= OPTION.lang then
				languageChanged = true
				OPTION.lang = newLang
				
				Canvas.setAttr(flagCanvObj, ATTR_X2, OPTION.lang*16)
				
				button.destroy(previousBt)
				previousBt = button.new(string.char(21).." "..language[OPTION.lang].goBack, 0, 0)
			end
		end
		
		if button.press(previousBt) then
			quit = true
		end
			
		render()
	end
	
	if languageChanged then	
		button.destroy(newWorldButton)
		button.destroy(selectButton)
		button.destroy(optionButton)
		button.destroy(quitButton)
		
		newWorldButton = button.new(language[OPTION.lang].creatNewW, nil, 32, 176, nil, nil, nil, true)
		if worldExist then
			selectButton = button.new(language[OPTION.lang].selectWorld, nil, 48, 176, nil, nil, nil, true)
		else
			selectButton = button.new(language[OPTION.lang].selectWorld, nil, 48, 176, nil, Color.new(12,12,12), nil, true)
		end
		optionButton = button.new(language[OPTION.lang].option, nil, 64, 176, nil, nil, nil, true)
		quitButton = button.new(language[OPTION.lang].quit, nil, 80, 176, nil, nil, nil, true)
		
		saveConfig()
	end
	
	previousBt = button.destroy(previousBt)
	collectgarbage("collect")
	Controls.read()
end

------------------------ -- Boucles -- ------------------------


quitMain = false
mapGenerating = false

flagImage = Image.load("images/flags.png", VRAM)
flagCanv = Canvas.new()
flagCanvObj = Canvas.newImage(0, 0, flagImage, OPTION.lang*16, 0, 16, 11)
Canvas.add(flagCanv, flagCanvObj)

-- V�rifie si exisite monde
System.changeDirectory("./saves")
local files = System.listDirectory(System.currentDirectory())
worldExist = false

for k, v in pairs(files) do
	if v.isDir and v.name ~= ".." and v.name ~= "." then
		worldExist = true
		break
	end
end
	
files = nil
System.changeDirectory("../")

newWorldButton = button.new(language[OPTION.lang].creatNewW, nil, 32, 176, nil, nil, nil, true)
if worldExist then
	selectButton = button.new(language[OPTION.lang].selectWorld, nil, 48, 176, nil, nil, nil, true)
else
	selectButton = button.new(language[OPTION.lang].selectWorld, nil, 48, 176, nil, Color.new(12,12,12), nil, true)
end
optionButton = button.new(language[OPTION.lang].option, nil, 64, 176, nil, nil, nil, true)
quitButton = button.new(language[OPTION.lang].quit, nil, 80, 176, nil, nil, nil, true)

worldNumber = nil
while not quitMain do
	Controls.read()
	
	screen.centerPrint(SCREEN_UP, 16, "Lumikha")
	screen.centerPrint(SCREEN_UP, 184, "Par Fantasix")
	
	Canvas.draw(SCREEN_DOWN, flagCanv, 0, 0)
	
	button.draw(newWorldButton, SCREEN_DOWN)
	button.draw(selectButton, SCREEN_DOWN)
	button.draw(optionButton, SCREEN_DOWN)
	button.draw(quitButton, SCREEN_DOWN)


	if button.press(newWorldButton) then
		newWorld()
	end
	if worldExist and button.press(selectButton) then
		selectScreen()
	end
	if button.press(optionButton) then
		optionScreen()
	end
	if button.press(quitButton) then
		quitMain = true
	end
	
	
	render()
end
		
newWorldButton = button.destroy(newWorldButton)
selectButton = button.destroy(selectButton)
optionButton = button.destroy(optionButton)
quitButton = button.destroy(quitButton)
	
Image.destroy(flagImage)
flagImage = nil

worldExist = nil

collectgarbage("collect")

if worldNumber then
	render()
	local timer = Timer.new()
	timer:start()
	while timer:time() < 500 do
		screen.print(SCREEN_DOWN, 4, 4, language[OPTION.lang].loading.." ...")
	
		render()
	end
	timer = nil
	
	if mapGenerating then
		dofile("files/mapGeneration.lua")
	end
	
	dofile("files/main.lua")
end