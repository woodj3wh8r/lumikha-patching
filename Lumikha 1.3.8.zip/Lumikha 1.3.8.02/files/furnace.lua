-------------------------------------------------------------------------------
--  Lumikha
--  Copyright (C) 2011 Fantasix
--
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
-------------------------------------------------------------------------------

furnace = {}

function furnace.load()
	furnace.list = {}
	
	local file = io.open("saves/"..worldNumber.."/furnace.ftsx", "r")
	local line = file:read()

	while line do
		if string.byte(string.sub(line, -1,-1)) == 13 or string.byte(string.sub(line, -1,-1)) == 10 then
			line = string.sub(line , 1, -2)
		end
		
		limit = nil
		
		sta, sto, id, x, y, fId, fQte, iId, iQte, rId, rQte, timer, limit = string.find(line, "(.+)|(.+)|(.+)|(.+)|(.+)|(.+)|(.+)|(.+)|(.+)|(.+)|(.+)")
		
		id = tonumber(id)
		x = tonumber(x)
		y = tonumber(y)
		fId = tonumber(fId)
		fQte = tonumber(fQte)
		iId = tonumber(iId)
		iQte = tonumber(iQte)
		rId = tonumber(rId)
		rQte = tonumber(rQte)
		timer = tonumber(timer)
		limit = tonumber(limit) 
		
		table.insert(furnace.list, id, {
			x = x, 
			y = y, 
			fuel = {id = fId, qte = fQte}, 
			item = {id = iId, qte = iQte}, 
			result = {id = rId, qte = rQte}, 
			inFurn = Timer.new(),
			timer = Timer.new(timer),
			limit = limit,
		})
		
		line = file:read()
	end

	io.close() 
	
	for k, v in pairs(furnace.list) do
		if v.timer:time() > 0 then
			v.timer:start()
		end
	end
	
end

function furnace.destroy()
	furnace.list = nil
end

function furnace.getID(x, y)
	for k, v in pairs(furnace.list) do
		if v.x == x and v.y == y then
			return k
		end
	end
	return -1
end

function furnace.newF(x, y)
	table.insert(furnace.list, {x = x, y = y, fuel = {id = 0, qte = 0}, item = {id = 0, qte = 0}, result = {id = 0, qte = 0}, inFurn = Timer.new(), timer = Timer.new(), limit = 0})
end

function furnace.removeF(x, y)
	furnace.list[furnace.getID(x, y)] = nil
end

function furnace.setFuel(idFur, idFuel, qteFuel)
	furnace.list[idFur].fuel = {id = idFuel, qte = qteFuel}
end

function furnace.setItem(idFur, idItem, qteItem)
	furnace.list[idFur].item = {id = idItem, qte = qteItem}
end

function furnace.setResult(idFur, idResult, qteResult)
	furnace.list[idFur].result = {id = idResult, qte = qteResult}
end

function furnace.act(onMap)
	for k, v in pairs(furnace.list) do
		-- On v�rifie si elle est en marche (Un combustible a �t� consomm�)
		if v.timer:isRunning() then -- Si transformation en cours
			if onMap and ScrollMap.getTile(map.scrollMap, v.x, v.y) == 66 then
				ScrollMap.setTile(map.scrollMap, v.x, v.y, 67)
			end
			if v.timer:time() < v.limit then -- Timer < � la limite
				if v.inFurn:time() >= 10000 then -- L'objet a �t� correctement transform� (10 sec par transformation)
					v.result.qte = v.result.qte + 1
					v.result.id = data.tab[v.item.id].smelted
					v.inFurn:reset()
					
					v.item.qte = v.item.qte - 1
					if v.item.qte == 0 then
						v.item.id = 0
					end
				else
					if v.inFurn:isRunning() then -- Si fonte en cours
						if v.item.id == 0 then -- Si l'objet a fondre a �t� retir�
							v.inFurn:reset()
						end
					else -- Si le timer n'est pas lanc�
						if data.tab[v.item.id].smelted then -- L'objet peut etre fondu
							if v.result.id == 0 or (v.result.id == data.tab[v.item.id].smelted and v.result.qte < data.tab[v.item.id].stack) then -- Si il n'y a rien dans le resultat ou que c'est le meme ID
								v.inFurn:start()
							end
						end
					end
				end
			else -- Timer > � la limite : reset du combustible + auto d�tection 
				v.timer:reset()
				v.limit = 0
				if data.tab[v.item.id].smelted and data.tab[v.fuel.id].fuelTime then -- Si nouvel objet � fondre + vrai fuel mis en place
					if v.result.id == 0 or (v.result.id > 0 and data.tab[v.result.id].stack and data.tab[v.item.id].smelted == v.result.id and v.result.qte < data.tab[v.item.id].stack) then
						v.timer:start()
						v.limit = data.tab[v.fuel.id].fuelTime
						
						v.fuel.qte = v.fuel.qte - 1
						if v.fuel.qte == 0 then
							v.fuel.id = 0
						end
					end
				end
			end
		else -- Si il n'est pas d�marr� 
			if onMap and ScrollMap.getTile(map.scrollMap, v.x, v.y) == 67 then
				ScrollMap.setTile(map.scrollMap, v.x, v.y, 66)
			end
			if data.tab[v.item.id].smelted and data.tab[v.fuel.id].fuelTime then -- Si nouvel objet � fondre + vrai fuel mis en place
				if v.result.id == 0 or (v.result.id > 0 and data.tab[v.result.id].stack and data.tab[v.item.id].smelted == v.result.id and v.result.qte < data.tab[v.item.id].stack) then
					v.timer:start()
					v.limit = data.tab[v.fuel.id].fuelTime
					
					v.fuel.qte = v.fuel.qte - 1
					if v.fuel.qte == 0 then
						v.fuel.id = 0
					end
				end
			end
			if v.inFurn:isRunning() then
				v.inFurn:reset()
			end
		end
	end
end

function furnace.show(idF)
		Controls.read()
		
		getPause(250)
		
		local furnaceImage = Image.load("images/furnace.png", VRAM)
		local furnaceSprites = Image.load("images/furnaceSprites.png", VRAM)
		local invCanv = Canvas.new()
		
		for i = 0, 8 do
			if inventory.tab[i+1][1] then
				local qte = inventory.tab[i+1][2]
				inventory.tab[i+1][3] = Canvas.newImage(48+i*18, 155, data.items, data.tab[inventory.tab[i+1][1]].coord[1], data.tab[inventory.tab[i+1][1]].coord[2], 16, 16)
				
				
				local typeItem = data.tab[inventory.tab[i+1][1]].type
				if typeItem == "block" or typeItem == "item" then
					inventory.tab[i+1][4] = Canvas.newText(48+i*18, 163, qte)
				else
					inventory.tab[i+1][4] = Canvas.newText(48+i*18, 163, "")
				end
			else
				inventory.tab[i+1][3] = Canvas.newImage(48+i*18, 155, data.items, 0, 0, 16, 16)
				inventory.tab[i+1][4] = Canvas.newText(48+i*18, 163, "")
			end
			Canvas.add(invCanv, inventory.tab[i+1][3])
			Canvas.add(invCanv, inventory.tab[i+1][4])
		end
		
		for i = 9, 35 do
			local x1 = i - 9
			x2 = math.floor(x1/9)
			if inventory.tab[i+1][1] then
				local qte = inventory.tab[i+1][2]
				inventory.tab[i+1][3] = Canvas.newImage(48+x1*18-x2*162, 97+x2*18, data.items, data.tab[inventory.tab[i+1][1]].coord[1], data.tab[inventory.tab[i+1][1]].coord[2], 16, 16)
				
				local typeItem = data.tab[inventory.tab[i+1][1]].type
				if typeItem == "block" or typeItem == "item" then
					inventory.tab[i+1][4] = Canvas.newText(48+x1*18-x2*162, 105+x2*18, qte)
				else
					inventory.tab[i+1][4] = Canvas.newText(48+x1*18-x2*162, 105+x2*18, "")
				end
			else
				inventory.tab[i+1][3] = Canvas.newImage(48+x1*18-x2*162, 97+x2*18, data.items, 0, 0, 16, 16)
				inventory.tab[i+1][4] = Canvas.newText(48+x1*18-x2*162, 105+x2*18, "")
			end
			Canvas.add(invCanv, inventory.tab[i+1][3])
			Canvas.add(invCanv, inventory.tab[i+1][4])
		end

		local prevPos = nil
		local underStylus = {0, 0}
		
		local function showRemainItems()
			if rPT[1] then -- Tableau des endroits o� ont �t� stack�s les items restant
				for i = 1, #rPT do
					Canvas.setAttr(inventory.tab[rPT[i]][3], ATTR_X2, data.tab[inventory.tab[rPT[i]][1]].coord[1])
					Canvas.setAttr(inventory.tab[rPT[i]][3], ATTR_Y2, data.tab[inventory.tab[rPT[i]][1]].coord[2])
					
					local typeItem = data.tab[inventory.tab[rPT[i]][1]].type
					if typeItem == "block" or typeItem == "item" then
						Canvas.setAttr(inventory.tab[rPT[i]][4], ATTR_TEXT, inventory.tab[rPT[i]][2])
					else
						Canvas.setAttr(inventory.tab[rPT[i]][4], ATTR_TEXT, "")
					end
				end
			end
		end
		
		local quitMenu = false
		while not quitMenu do
			Controls.read()
			
			if Keys.newPress.Select then
				quitMenu = true
			elseif Stylus.doubleClick and underStylus[1] == 0 then
				local sX = Stylus.X
				local sY = Stylus.Y
				
				if not (sX >= 41 and sX <= 214 and sY >= 14 and sY <= 177) then
					quitMenu = true
				end
			end
			
			constantFunction()
			
			screen.blit(SCREEN_DOWN, 41, 14, furnaceImage)
			
			-- ******************** AFFICHAGE ******************** --
		
			Canvas.draw(SCREEN_DOWN, invCanv, 0, 0)	
			
			-- Combustible (Flamme)
			
			if furnace.list[idF].timer:isRunning() then
				local cut = math.floor((furnace.list[idF].timer:time()/furnace.list[idF].limit)*15)
				screen.blit(SCREEN_DOWN, 96, 49+cut, furnaceSprites, 0, 0+cut, 15, 15-cut)
			end
			
			-- Transformation en cours (Fleche)
			
			if furnace.list[idF].inFurn:isRunning() then
				local cut = math.floor((furnace.list[idF].inFurn:time()/10000)*23)
				screen.blit(SCREEN_DOWN, 119, 48, furnaceSprites, 0, 15, 0+cut, 15)
			end
			
			-- Fuel
			if furnace.list[idF].fuel.id > 0 then
				local qte = furnace.list[idF].fuel.qte
				local id = furnace.list[idF].fuel.id
				
				screen.blit(SCREEN_DOWN, 96, 66, data.items, data.tab[id].coord[1], data.tab[id].coord[2], 16, 16)
				
				local typeItem = data.tab[id].type
				if typeItem == "block" or typeItem == "item" then
					screen.print(SCREEN_DOWN, 96, 74, qte)
				end
			end

			-- Item
			if furnace.list[idF].item.id > 0 then
				local qte = furnace.list[idF].item.qte
				local id = furnace.list[idF].item.id
				
				screen.blit(SCREEN_DOWN, 96, 30, data.items, data.tab[id].coord[1], data.tab[id].coord[2], 16, 16)
				
				local typeItem = data.tab[id].type
				if typeItem == "block" or typeItem == "item" then
					screen.print(SCREEN_DOWN, 96, 38, qte)
				end
			end
			
			-- Result
			if furnace.list[idF].result.id > 0 then
				local qte = furnace.list[idF].result.qte
				local id = furnace.list[idF].result.id
				
				screen.blit(SCREEN_DOWN, 156, 48, data.items, data.tab[id].coord[1], data.tab[id].coord[2], 16, 16)
				
				local typeItem = data.tab[id].type
				if typeItem == "block" or typeItem == "item" then
					screen.print(SCREEN_DOWN, 156, 54, qte)
				end
			end
			
			-- ******************** GESTION CRAFT ******************** --
			
			if Stylus.newPress and underStylus[1] == 0 then
				-- Rep�rage de la case
				local sX = Stylus.X
				local sY = Stylus.Y
				
				if sX >= 47 and sX <= 208 then
					if sY >= 154 and sY <= 171 then -- Barre du bas
						local indexInv = math.ceil((Stylus.X-47)/18)
						local idItem = inventory.tab[indexInv][1]
						if idItem then
							underStylus[1] = idItem
							underStylus[2] = 1
							prevPos = indexInv
							
							if Ambi.held.Down() then -- Si on appuie en bas, on prend le stack entier
								underStylus[2] = inventory.tab[indexInv][2]
							elseif Ambi.held.Right() or Ambi.held.Left() then
								underStylus[2] = math.ceil(inventory.tab[indexInv][2] / 2)
							end
							
							inventory.removeItem(indexInv, underStylus[2])
							if not inventory.tab[indexInv][1] then
								Canvas.setAttr(inventory.tab[indexInv][3], ATTR_X2, 0)
								Canvas.setAttr(inventory.tab[indexInv][3], ATTR_Y2, 0)
								Canvas.setAttr(inventory.tab[indexInv][4], ATTR_TEXT, "")
							else
								Canvas.setAttr(inventory.tab[indexInv][4], ATTR_TEXT, inventory.tab[indexInv][2])
							end
						end
					elseif sY >= 96 and sY <= 149 then -- Inventaire principal
						local indexInv = 9 + math.ceil((Stylus.X-47)/18) + math.floor((Stylus.Y-96)/18)*9
						local idItem = inventory.tab[indexInv][1]
						if idItem then
							underStylus[1] = idItem
							underStylus[2] = 1
							prevPos = indexInv
							
							if Ambi.held.Down() then -- Si on appuie en bas, on prend le stack entier
								underStylus[2] = inventory.tab[indexInv][2]
							elseif Ambi.held.Right() or Ambi.held.Left() then
								underStylus[2] = math.ceil(inventory.tab[indexInv][2] / 2)
							end
							
							inventory.removeItem(indexInv, underStylus[2])
							if not inventory.tab[indexInv][1] then
								Canvas.setAttr(inventory.tab[indexInv][3], ATTR_X2, 0)
								Canvas.setAttr(inventory.tab[indexInv][3], ATTR_Y2, 0)
								Canvas.setAttr(inventory.tab[indexInv][4], ATTR_TEXT, "")
							else
								Canvas.setAttr(inventory.tab[indexInv][4], ATTR_TEXT, inventory.tab[indexInv][2])
							end
						end
					elseif sY >= 66 and sY <= 81 and sX >= 96 and sX <= 111 then -- Fuel
						local idItem = furnace.list[idF].fuel.id
						
						if idItem > 0 then
							underStylus[1] = idItem
							underStylus[2] = 1
							
							if Ambi.held.Down() then -- Si on appuie en bas, on prend le stack entier
								underStylus[2] = furnace.list[idF].fuel.qte
							elseif Ambi.held.Right() or Ambi.held.Left() then
								underStylus[2] = math.ceil(furnace.list[idF].fuel.qte / 2)
							end
							
							furnace.list[idF].fuel.qte = furnace.list[idF].fuel.qte - underStylus[2]
							if furnace.list[idF].fuel.qte == 0 then
								furnace.list[idF].fuel.id = 0
							end							
						end
					elseif sY >= 30 and sY <= 45 and sX >= 96 and sX <= 111 then -- Item
						local idItem = furnace.list[idF].item.id
						
						if idItem > 0 then
							underStylus[1] = idItem
							underStylus[2] = 1
							
							if Ambi.held.Down() then -- Si on appuie en bas, on prend le stack entier
								underStylus[2] = furnace.list[idF].item.qte
							elseif Ambi.held.Right() or Ambi.held.Left() then
								underStylus[2] = math.ceil(furnace.list[idF].item.qte / 2)
							end
							
							furnace.list[idF].item.qte = furnace.list[idF].item.qte - underStylus[2]
							if furnace.list[idF].item.qte == 0 then
								furnace.list[idF].item.id = 0
							end							
						end
					elseif sY >= 48 and sY <= 63 and sX >= 156 and sX <= 171 then -- Result
						local idItem = furnace.list[idF].result.id
						
						if idItem > 0 then
							underStylus[1] = idItem
							underStylus[2] = 1
							
							if Ambi.held.Down() then -- Si on appuie en bas, on prend le stack entier
								underStylus[2] = furnace.list[idF].result.qte
							elseif Ambi.held.Right() or Ambi.held.Left() then
								underStylus[2] = math.ceil(furnace.list[idF].result.qte / 2)
							end
							
							furnace.list[idF].result.qte = furnace.list[idF].result.qte - underStylus[2]
							if furnace.list[idF].result.qte == 0 then
								furnace.list[idF].result.id = 0
							end							
						end
					end
				end
			elseif Stylus.released and underStylus[1] > 0 then
				local sX = Stylus.X
				local sY = Stylus.Y
				local indexInv = nil
				local toFurnFuel = false
				local toFurnItem = false
				rPT = {}
				
				if sX >= 47 and sX <= 208 then
					if sY >= 154 and sY <= 171 then
						indexInv = math.ceil((Stylus.X-47)/18)
					elseif sY >= 96 and sY <= 149 then
						indexInv = 9 + math.ceil((Stylus.X-47)/18) + math.floor((Stylus.Y-96)/18)*9
					elseif sY >= 66 and sY <= 81 and sX >= 96 and sX <= 111 then -- Fuel
						toFurnFuel = true
					elseif sY >= 30 and sY <= 45 and sX >= 96 and sX <= 111 then -- Item
						toFurnItem = true
					end
				end
				
				if toFurnFuel then
					if furnace.list[idF].fuel.id > 0 then
						local typeItem = data.tab[furnace.list[idF].fuel.id].type
						if furnace.list[idF].fuel.id == underStylus[1] and (typeItem == "block" or typeItem == "item") then
							furnace.list[idF].fuel.qte = furnace.list[idF].fuel.qte + underStylus[2]
							
							underStylus[2] = 0
							
							if furnace.list[idF].fuel.qte > data.tab[furnace.list[idF].fuel.id].stack then
								underStylus[2] = furnace.list[idF].fuel.qte - data.tab[furnace.list[idF].fuel.id].stack
								furnace.list[idF].fuel.qte = data.tab[furnace.list[idF].fuel.id].stack
								
								rPT = inventory.addItem(underStylus[1], underStylus[2], furnace.list[idF].fuel.id)
							end
						else
							rPT = inventory.addItem(underStylus[1], underStylus[2])
						end
					else
						furnace.list[idF].fuel.id = underStylus[1]
						furnace.list[idF].fuel.qte = underStylus[2]
					end
				elseif toFurnItem then
					if furnace.list[idF].item.id > 0 then
						local typeItem = data.tab[furnace.list[idF].item.id].type
						if furnace.list[idF].item.id == underStylus[1] and (typeItem == "block" or typeItem == "item") then
							furnace.list[idF].item.qte = furnace.list[idF].item.qte + underStylus[2]
							
							underStylus[2] = 0
							
							if furnace.list[idF].item.qte > data.tab[furnace.list[idF].item.id].stack then
								underStylus[2] = furnace.list[idF].item.qte - data.tab[furnace.list[idF].item.id].stack
								furnace.list[idF].item.qte = data.tab[furnace.list[idF].item.id].stack
								
								rPT = inventory.addItem(underStylus[1], underStylus[2], furnace.list[idF].item.id)
							end
						else
							rPT = inventory.addItem(underStylus[1], underStylus[2])
						end
					else
						furnace.list[idF].item.id = underStylus[1]
						furnace.list[idF].item.qte = underStylus[2]
					end
				else
					rPT = inventory.addItem(underStylus[1], underStylus[2], indexInv, prevPos)
					
					if indexInv then
						Canvas.setAttr(inventory.tab[indexInv][3], ATTR_X2, data.tab[inventory.tab[indexInv][1]].coord[1])
						Canvas.setAttr(inventory.tab[indexInv][3], ATTR_Y2, data.tab[inventory.tab[indexInv][1]].coord[2])
						
						local typeItem = data.tab[inventory.tab[indexInv][1]].type
						if typeItem == "block" or typeItem == "item" then
							Canvas.setAttr(inventory.tab[indexInv][4], ATTR_TEXT, inventory.tab[indexInv][2])
						else
							Canvas.setAttr(inventory.tab[indexInv][4], ATTR_TEXT, "")
						end
						
						if prevPos and inventory.tab[prevPos][1] then
							Canvas.setAttr(inventory.tab[prevPos][3], ATTR_X2, data.tab[inventory.tab[prevPos][1]].coord[1])
							Canvas.setAttr(inventory.tab[prevPos][3], ATTR_Y2, data.tab[inventory.tab[prevPos][1]].coord[2])
							
							local typeItem = data.tab[inventory.tab[prevPos][1]].type
							if typeItem == "block" or typeItem == "item" then
								Canvas.setAttr(inventory.tab[prevPos][4], ATTR_TEXT, inventory.tab[prevPos][2])
							else
								Canvas.setAttr(inventory.tab[prevPos][4], ATTR_TEXT, "")
							end
						end
					end	
				end
				showRemainItems()
				
				
				underStylus[1] = 0
				underStylus[2] = 0
				
				prevPos = nil
			elseif underStylus[1] > 0 then
				screen.blit(SCREEN_DOWN, Stylus.X - 8, Stylus.Y - 8, data.items, data.tab[underStylus[1]].coord[1], data.tab[underStylus[1]].coord[2], 16, 16)
				if underStylus[2] and underStylus[2] > 0 then
					screen.print(SCREEN_DOWN, Stylus.X - 8, Stylus.Y, underStylus[2])
				end
			end
			
			-- ******************** ******************** --
			screen.print(SCREEN_UP, 0, 184, NB_FPS)
			
			render()
		end
		getPause(250)
		
		Canvas.destroy(invCanv)
		invCanv = nil
		Image.destroy(furnaceSprites)
		furnaceSprites = nil
		Image.destroy(furnaceImage)
		furnaceImage = nil
		
		collectgarbage("collect")
		
		getPause(250)
		
		Controls.read()
end