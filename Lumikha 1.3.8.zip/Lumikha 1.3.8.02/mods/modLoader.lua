-------------------------------------------------------------------------------
--  Lumikha
--  Copyright (C) 2011 Fantasix
--
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
-------------------------------------------------------------------------------

System.changeDirectory("./mods")
local path = System.currentDirectory()
local files = System.listDirectory(path)

MODS_TAB = {
	loopMods = {},
	endMods = {}
}

function addEndMod(name, func)
	if func and type(func) == "function" and name and type(name) == "string" then
		MODS_TAB.endMods[name] = func
	end
end

function removeEndMod(name)
	if name and type(name) == "string" then
		MODS_TAB.endMods[name] = nil
	end
end

function addLoopMod(name, func)
	if func and type(func) == "function" and name and type(name) == "string" then
		MODS_TAB.loopMods[name] = func
	end
end

function removeLoopMod(name)
	if name and type(name) == "string" then
		MODS_TAB.loopMods[name] = nil
	end
end

for k, v in pairs(files) do
	if not v.isDir and v.name ~= "modLoader.lua" then
		local name = string.sub(v.name, 1, -5)
		local ext = string.sub(v.name, -3)
		local onOff = string.sub(v.name, 1, 2)
		if ext == "lua" and onOff ~= "--" then
			dofile(path.."/"..v.name)
		end
	end
end

addMod = nil
path = nil
files = nil

System.changeDirectory("../")