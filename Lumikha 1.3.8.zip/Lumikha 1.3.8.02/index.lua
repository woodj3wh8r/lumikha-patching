-------------------------------------------------------------------------------
--  LuaCraft
--  Copyright (C) 2011 Fantasix
--
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
-------------------------------------------------------------------------------

VERSION = "1.3.8"

math.randomseed(os.time())

dofile("files/functions.lua")

dofile("files/option.lua")

dofile("files/language.lua")

dofile("files/inventory.lua")

dofile("files/craftingTable.lua")

dofile("files/furnace.lua")

dofile("files/chest.lua")

dofile("files/character.lua")

dofile("files/map.lua")

dofile("files/database.lua")

dofile("files/Timer.lua")

dofile("files/timeCycle.lua")

dofile("files/sapling.lua")

-- Go to Title

dofile("files/title.lua")

